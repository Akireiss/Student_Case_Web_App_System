
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `accidents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accidents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profile_id` bigint(20) unsigned NOT NULL,
  `accidents` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accidents_profile_id_foreign` (`profile_id`),
  CONSTRAINT `accidents_profile_id_foreign` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `accidents` WRITE;
/*!40000 ALTER TABLE `accidents` DISABLE KEYS */;
INSERT INTO `accidents` VALUES (142,57,'Explicabo Aut fuga','2023-09-02 08:50:17','2023-09-02 08:50:17'),(143,57,'Laudantium in unde ','2023-09-02 08:50:17','2023-09-02 08:50:17'),(144,57,'Sapiente aut enim si','2023-09-02 08:50:17','2023-09-02 08:50:17'),(145,58,'Nostrum suscipit Nam','2023-09-02 08:56:33','2023-09-02 08:56:33'),(146,58,'Minima ut laboriosam','2023-09-02 08:56:33','2023-09-02 08:56:33'),(147,58,'Architecto mollit mo','2023-09-02 08:56:33','2023-09-02 08:56:33');
/*!40000 ALTER TABLE `accidents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_taken` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `actions` WRITE;
/*!40000 ALTER TABLE `actions` DISABLE KEYS */;
INSERT INTO `actions` VALUES (1,'Parent Teacher Meeting',NULL,NULL),(2,'Letter',NULL,NULL),(3,'Anecdotal Collect',NULL,NULL),(4,'Parent Call',NULL,NULL);
/*!40000 ALTER TABLE `actions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `actions_taken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actions_taken` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `anecdotal_id` bigint(20) unsigned NOT NULL,
  `actions` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `actions_taken_anecdotal_id_foreign` (`anecdotal_id`),
  CONSTRAINT `actions_taken_anecdotal_id_foreign` FOREIGN KEY (`anecdotal_id`) REFERENCES `anecdotal` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `actions_taken` WRITE;
/*!40000 ALTER TABLE `actions_taken` DISABLE KEYS */;
INSERT INTO `actions_taken` VALUES (71,47,'Anecdotal Collect','2023-08-22 17:53:43','2023-08-22 17:53:43'),(72,48,'Letter','2023-08-22 17:58:30','2023-08-22 17:58:30'),(91,46,'Parent Call','2023-08-23 03:33:54','2023-08-23 03:33:54'),(92,46,'Letter','2023-08-23 03:33:54','2023-08-23 03:33:54'),(93,49,'Letter','2023-08-23 03:42:17','2023-08-23 03:42:17'),(94,49,'Parent Call','2023-08-23 03:42:17','2023-08-23 03:42:17'),(95,50,'Letter','2023-08-26 03:40:55','2023-08-26 03:40:55'),(96,51,'Parent Teacher Meeting','2023-08-26 18:33:47','2023-08-26 18:33:47'),(97,51,'Letter','2023-08-26 18:33:47','2023-08-26 18:33:47'),(98,52,'Letter','2023-08-29 12:01:26','2023-08-29 12:01:26'),(99,53,'Letter','2023-08-29 23:30:31','2023-08-29 23:30:31'),(100,53,'Parent Call','2023-08-29 23:30:31','2023-08-29 23:30:31'),(103,54,'Letter','2023-08-29 23:35:53','2023-08-29 23:35:53'),(104,54,'Parent Teacher Meeting','2023-08-29 23:35:53','2023-08-29 23:35:53'),(105,55,'Letter','2023-08-29 23:37:08','2023-08-29 23:37:08'),(106,55,'Parent Call','2023-08-29 23:37:08','2023-08-29 23:37:08'),(107,56,'Parent Call','2023-09-02 00:32:10','2023-09-02 00:32:10'),(108,56,'Letter','2023-09-02 00:32:10','2023-09-02 00:32:10'),(111,58,'Parent Teacher Meeting','2023-09-02 07:51:56','2023-09-02 07:51:56'),(112,58,'Letter','2023-09-02 07:51:56','2023-09-02 07:51:56'),(113,57,'Parent Teacher Meeting','2023-09-02 07:52:39','2023-09-02 07:52:39'),(114,57,'Letter','2023-09-02 07:52:39','2023-09-02 07:52:39');
/*!40000 ALTER TABLE `actions_taken` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_id` bigint(20) unsigned DEFAULT NULL,
  `causer_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_id` bigint(20) unsigned DEFAULT NULL,
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`properties`)),
  `batch_uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject` (`subject_type`,`subject_id`),
  KEY `causer` (`causer_type`,`causer_id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,'default','created','App\\Models\\User','created',1,NULL,NULL,'{\"attributes\":{\"name\":\"Admin\",\"email\":\"admin@gmail.com\",\"password\":\"$2y$10$SluAl.JKpB71YT8wzNp9k.FnSemU2v3BEdbjgKWrkDKg6aHes11iC\"}}',NULL,'2023-08-19 16:52:00','2023-08-19 16:52:00'),(2,'default','created','App\\Models\\Anecdotal','created',1,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"Et enim dolores pers\"}}',NULL,'2023-08-19 17:37:05','2023-08-19 17:37:05'),(3,'default','created','App\\Models\\Anecdotal','created',2,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Ut nulla non consequ\",\"outcome\":\"Fugiat dolor incidu\"}}',NULL,'2023-08-19 18:26:17','2023-08-19 18:26:17'),(4,'default','created','App\\Models\\Anecdotal','created',3,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Accusamus laborum Q\",\"outcome\":\"Et pariatur Omnis a\"}}',NULL,'2023-08-19 18:41:18','2023-08-19 18:41:18'),(5,'default','created','App\\Models\\Anecdotal','created',4,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Doloribus placeat b\",\"outcome\":\"Et enim dolores pers\"}}',NULL,'2023-08-19 18:43:18','2023-08-19 18:43:18'),(6,'default','created','App\\Models\\Anecdotal','created',5,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":3,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"Amet aut molestiae \"}}',NULL,'2023-08-19 18:54:16','2023-08-19 18:54:16'),(7,'default','created','App\\Models\\Anecdotal','created',6,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Nisi quod laborum S\",\"outcome\":\"Praesentium distinct\"}}',NULL,'2023-08-20 04:31:48','2023-08-20 04:31:48'),(8,'default','created','App\\Models\\Anecdotal','created',7,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Deserunt exercitatio\",\"outcome\":\"Asperiores cumque la\"}}',NULL,'2023-08-20 04:32:28','2023-08-20 04:32:28'),(9,'default','created','App\\Models\\Anecdotal','created',8,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"Et enim dolores pers\"}}',NULL,'2023-08-20 16:42:28','2023-08-20 16:42:28'),(10,'default','created','App\\Models\\Anecdotal','created',9,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Ullam unde ex aperia\",\"outcome\":\"Omnis sed culpa est\"}}',NULL,'2023-08-20 18:26:20','2023-08-20 18:26:20'),(11,'default','created','App\\Models\\Anecdotal','created',10,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"Amet aut molestiae \"}}',NULL,'2023-08-20 21:39:35','2023-08-20 21:39:35'),(12,'default','created','App\\Models\\Anecdotal','created',11,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":7,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"Et enim dolores pers\"}}',NULL,'2023-08-20 21:48:58','2023-08-20 21:48:58'),(13,'default','created','App\\Models\\Anecdotal','created',12,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":7,\"short_description\":\"Doloribus placeat b\",\"outcome\":\"Amet aut molestiae \"}}',NULL,'2023-08-20 21:49:45','2023-08-20 21:49:45'),(14,'default','created','App\\Models\\Anecdotal','created',13,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":7,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"Et enim dolores pers\"}}',NULL,'2023-08-20 21:57:04','2023-08-20 21:57:04'),(15,'default','created','App\\Models\\Anecdotal','created',14,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"Et enim dolores pers\"}}',NULL,'2023-08-20 22:28:21','2023-08-20 22:28:21'),(16,'default','created','App\\Models\\Anecdotal','created',15,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Quaerat error velit \",\"outcome\":\"Nulla iure et amet \"}}',NULL,'2023-08-20 22:35:33','2023-08-20 22:35:33'),(17,'default','created','App\\Models\\Anecdotal','created',16,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Aut velit ducimus n\",\"outcome\":\"Consequatur Eiusmod\"}}',NULL,'2023-08-20 22:41:40','2023-08-20 22:41:40'),(18,'default','created','App\\Models\\Anecdotal','created',17,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Praesentium explicab\",\"outcome\":\"Culpa omnis esse m\"}}',NULL,'2023-08-20 22:42:05','2023-08-20 22:42:05'),(19,'default','created','App\\Models\\Anecdotal','created',18,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Et amet veniam dol\",\"outcome\":\"Ex consequatur In u\"}}',NULL,'2023-08-21 04:15:02','2023-08-21 04:15:02'),(20,'default','created','App\\Models\\Anecdotal','created',19,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Doloribus placeat b\",\"outcome\":\"Et enim dolores pers\"}}',NULL,'2023-08-21 04:18:27','2023-08-21 04:18:27'),(21,'default','created','App\\Models\\Anecdotal','created',20,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"Et enim dolores pers\"}}',NULL,'2023-08-21 04:46:32','2023-08-21 04:46:32'),(22,'default','created','App\\Models\\Anecdotal','created',21,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Consequatur molliti\",\"outcome\":\"Cupidatat eos amet\"}}',NULL,'2023-08-21 04:50:06','2023-08-21 04:50:06'),(23,'default','created','App\\Models\\Anecdotal','created',22,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Anim exercitationem \",\"outcome\":\"Fugiat quibusdam ea\"}}',NULL,'2023-08-21 05:28:42','2023-08-21 05:28:42'),(24,'default','created','App\\Models\\Anecdotal','created',23,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":7,\"short_description\":\"Iusto tenetur aliqua\",\"outcome\":\"Qui nulla dolore vol\"}}',NULL,'2023-08-21 05:32:10','2023-08-21 05:32:10'),(25,'default','created','App\\Models\\Anecdotal','created',24,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Iusto exercitation i\",\"outcome\":\"Fugiat sed fugiat \"}}',NULL,'2023-08-21 05:32:20','2023-08-21 05:32:20'),(26,'default','created','App\\Models\\Anecdotal','created',25,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Magni quod sit ut f\",\"outcome\":\"Quaerat quae tempori\"}}',NULL,'2023-08-21 05:32:32','2023-08-21 05:32:32'),(27,'default','created','App\\Models\\Anecdotal','created',26,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Laborum Deleniti im\",\"outcome\":\"Et eum eos ut et et \"}}',NULL,'2023-08-21 05:32:45','2023-08-21 05:32:45'),(28,'default','created','App\\Models\\Anecdotal','created',27,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Aut necessitatibus i\",\"outcome\":\"Id aut nostrud mole\"}}',NULL,'2023-08-21 05:35:42','2023-08-21 05:35:42'),(29,'default','created','App\\Models\\Anecdotal','created',28,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Mollit non ad quis d\",\"outcome\":\"Illum corporis culp\"}}',NULL,'2023-08-21 05:35:59','2023-08-21 05:35:59'),(30,'default','updated','App\\Models\\Anecdotal','updated',25,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Magni quod sit ut f\",\"outcome\":\"Quaerat quae tempori\"},\"old\":{\"student_id\":1,\"short_description\":\"Magni quod sit ut f\",\"outcome\":\"Quaerat quae tempori\"}}',NULL,'2023-08-21 17:15:48','2023-08-21 17:15:48'),(31,'default','updated','App\\Models\\Anecdotal','updated',27,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Aut necessitatibus i\",\"outcome\":\"Id aut nostrud mole\"},\"old\":{\"student_id\":6,\"short_description\":\"Aut necessitatibus i\",\"outcome\":\"Id aut nostrud mole\"}}',NULL,'2023-08-21 17:18:40','2023-08-21 17:18:40'),(32,'default','updated','App\\Models\\Anecdotal','updated',27,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Aut necessitatibus i\",\"outcome\":\"Id aut nostrud mole\"},\"old\":{\"student_id\":6,\"short_description\":\"Aut necessitatibus i\",\"outcome\":\"Id aut nostrud mole\"}}',NULL,'2023-08-21 17:21:33','2023-08-21 17:21:33'),(33,'default','updated','App\\Models\\Anecdotal','updated',26,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Laborum Deleniti im\",\"outcome\":\"Et eum eos ut et et \"},\"old\":{\"student_id\":6,\"short_description\":\"Laborum Deleniti im\",\"outcome\":\"Et eum eos ut et et \"}}',NULL,'2023-08-21 18:04:29','2023-08-21 18:04:29'),(34,'default','updated','App\\Models\\Anecdotal','updated',23,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":7,\"short_description\":\"Iusto tenetur aliqua\",\"outcome\":\"Qui nulla dolore vol\"},\"old\":{\"student_id\":7,\"short_description\":\"Iusto tenetur aliqua\",\"outcome\":\"Qui nulla dolore vol\"}}',NULL,'2023-08-21 18:05:35','2023-08-21 18:05:35'),(35,'default','updated','App\\Models\\Anecdotal','updated',24,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Iusto exercitation i\",\"outcome\":\"Fugiat sed fugiat \"},\"old\":{\"student_id\":6,\"short_description\":\"Iusto exercitation i\",\"outcome\":\"Fugiat sed fugiat \"}}',NULL,'2023-08-21 18:06:28','2023-08-21 18:06:28'),(36,'default','updated','App\\Models\\Anecdotal','updated',24,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Iusto exercitation i\",\"outcome\":\"Fugiat sed fugiat \"},\"old\":{\"student_id\":6,\"short_description\":\"Iusto exercitation i\",\"outcome\":\"Fugiat sed fugiat \"}}',NULL,'2023-08-21 18:08:00','2023-08-21 18:08:00'),(37,'default','updated','App\\Models\\Anecdotal','updated',23,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":7,\"short_description\":\"Iusto tenetur aliqua\",\"outcome\":\"Qui nulla dolore vol\"},\"old\":{\"student_id\":7,\"short_description\":\"Iusto tenetur aliqua\",\"outcome\":\"Qui nulla dolore vol\"}}',NULL,'2023-08-21 18:09:18','2023-08-21 18:09:18'),(38,'default','updated','App\\Models\\Anecdotal','updated',21,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Consequatur molliti\",\"outcome\":\"Cupidatat eos amet\"},\"old\":{\"student_id\":6,\"short_description\":\"Consequatur molliti\",\"outcome\":\"Cupidatat eos amet\"}}',NULL,'2023-08-21 18:10:29','2023-08-21 18:10:29'),(39,'default','created','App\\Models\\Anecdotal','created',29,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"At consectetur modi \"}}',NULL,'2023-08-21 21:24:39','2023-08-21 21:24:39'),(40,'default','created','App\\Models\\Anecdotal','created',30,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"At consectetur modi \"}}',NULL,'2023-08-21 21:28:26','2023-08-21 21:28:26'),(41,'default','created','App\\Models\\Anecdotal','created',31,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Hic dolore quaerat o\",\"outcome\":\"Reprehenderit ut eni\"}}',NULL,'2023-08-21 21:30:39','2023-08-21 21:30:39'),(42,'default','created','App\\Models\\Anecdotal','created',32,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Dolor tempor aute en\",\"outcome\":\"Ipsum debitis corrup\"}}',NULL,'2023-08-22 04:19:14','2023-08-22 04:19:14'),(43,'default','created','App\\Models\\Anecdotal','created',33,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Doloribus placeat b\",\"outcome\":\"Et enim dolores pers\"}}',NULL,'2023-08-22 04:21:34','2023-08-22 04:21:34'),(44,'default','created','App\\Models\\Anecdotal','created',34,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Molestiae est sed e\",\"outcome\":\"Ea corporis non volu\"}}',NULL,'2023-08-22 04:23:42','2023-08-22 04:23:42'),(45,'default','updated','App\\Models\\Anecdotal','updated',34,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Molestiae est sed e\",\"outcome\":\"Ea corporis non volu\"},\"old\":{\"student_id\":6,\"short_description\":\"Molestiae est sed e\",\"outcome\":\"Ea corporis non volu\"}}',NULL,'2023-08-22 04:31:15','2023-08-22 04:31:15'),(46,'default','updated','App\\Models\\Anecdotal','updated',33,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Doloribus placeat b\",\"outcome\":\"Et enim dolores pers\"},\"old\":{\"student_id\":6,\"short_description\":\"Doloribus placeat b\",\"outcome\":\"Et enim dolores pers\"}}',NULL,'2023-08-22 04:55:03','2023-08-22 04:55:03'),(47,'default','updated','App\\Models\\Anecdotal','updated',31,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Hic dolore quaerat o\",\"outcome\":\"Reprehenderit ut eni\"},\"old\":{\"student_id\":6,\"short_description\":\"Hic dolore quaerat o\",\"outcome\":\"Reprehenderit ut eni\"}}',NULL,'2023-08-22 04:58:42','2023-08-22 04:58:42'),(48,'default','updated','App\\Models\\Anecdotal','updated',30,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"At consectetur modi \"},\"old\":{\"student_id\":6,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"At consectetur modi \"}}',NULL,'2023-08-22 04:58:56','2023-08-22 04:58:56'),(49,'default','created','App\\Models\\Anecdotal','created',35,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"At consectetur modi \"}}',NULL,'2023-08-22 05:01:54','2023-08-22 05:01:54'),(50,'default','created','App\\Models\\User','created',2,NULL,NULL,'{\"attributes\":{\"name\":\"Adviser\",\"email\":\"adviser@gmail.com\",\"password\":\"$2y$10$qki9cfjZwzE0ZSNtJGLj9.KH0yh0FQDzSIRb.i2d.eGy7NktKjCC6\"}}',NULL,'2023-08-22 05:03:09','2023-08-22 05:03:09'),(51,'default','created','App\\Models\\Anecdotal','created',36,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Veniam id consequat\",\"outcome\":\"Sunt vel dolor conse\"}}',NULL,'2023-08-22 16:45:58','2023-08-22 16:45:58'),(52,'default','created','App\\Models\\Anecdotal','created',37,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Velit ipsum necess\",\"outcome\":\"Est doloribus magni\"}}',NULL,'2023-08-22 16:47:07','2023-08-22 16:47:07'),(53,'default','updated','App\\Models\\Anecdotal','updated',37,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Velit ipsum necess\",\"outcome\":\"Est doloribus magni\"},\"old\":{\"student_id\":6,\"short_description\":\"Velit ipsum necess\",\"outcome\":\"Est doloribus magni\"}}',NULL,'2023-08-22 16:47:24','2023-08-22 16:47:24'),(54,'default','created','App\\Models\\Anecdotal','created',38,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Adipisicing nesciunt\",\"outcome\":\"Id amet consequatur\"}}',NULL,'2023-08-22 16:53:51','2023-08-22 16:53:51'),(55,'default','created','App\\Models\\Anecdotal','created',39,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":19,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"Amet aut molestiae \"}}',NULL,'2023-08-22 16:58:24','2023-08-22 16:58:24'),(56,'default','created','App\\Models\\Anecdotal','created',40,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Quod rem voluptatem \",\"outcome\":\"Est necessitatibus \"}}',NULL,'2023-08-22 17:10:10','2023-08-22 17:10:10'),(57,'default','created','App\\Models\\Anecdotal','created',41,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":1,\"short_description\":\"At recusandae Liber\",\"outcome\":\"Ut saepe unde veniam\"}}',NULL,'2023-08-22 17:16:11','2023-08-22 17:16:11'),(58,'default','created','App\\Models\\Anecdotal','created',42,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":19,\"short_description\":\"Autem quod voluptas \",\"outcome\":\"Dolor et molestiae s\"}}',NULL,'2023-08-22 17:19:05','2023-08-22 17:19:05'),(59,'default','created','App\\Models\\Anecdotal','created',43,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":19,\"short_description\":\"Dolore ut qui ut dol\",\"outcome\":\"Ut voluptates ullamc\"}}',NULL,'2023-08-22 17:21:09','2023-08-22 17:21:09'),(60,'default','created','App\\Models\\Anecdotal','created',44,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Consequuntur magni q\",\"outcome\":\"Sed et consequuntur \"}}',NULL,'2023-08-22 17:21:30','2023-08-22 17:21:30'),(61,'default','created','App\\Models\\Anecdotal','created',45,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Adipisicing tempor e\",\"outcome\":\"Tenetur quam facere \"}}',NULL,'2023-08-22 17:21:47','2023-08-22 17:21:47'),(62,'default','created','App\\Models\\Anecdotal','created',46,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Cupiditate sed quis \",\"outcome\":\"Dolorem nemo debitis\"}}',NULL,'2023-08-22 17:51:31','2023-08-22 17:51:31'),(63,'default','created','App\\Models\\Anecdotal','created',47,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Sapiente qui in volu\",\"outcome\":\"Et dignissimos ipsum\"}}',NULL,'2023-08-22 17:53:43','2023-08-22 17:53:43'),(64,'default','created','App\\Models\\Anecdotal','created',48,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Velit qui commodo in\",\"outcome\":\"Qui perferendis duis\"}}',NULL,'2023-08-22 17:58:30','2023-08-22 17:58:30'),(65,'default','updated','App\\Models\\Anecdotal','updated',46,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":6,\"short_description\":null,\"outcome\":\"Dolorem nemo debitis\"},\"old\":{\"student_id\":6,\"short_description\":\"Cupiditate sed quis \",\"outcome\":\"Dolorem nemo debitis\"}}',NULL,'2023-08-23 03:24:57','2023-08-23 03:24:57'),(66,'default','updated','App\\Models\\Anecdotal','updated',46,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Reiss\",\"outcome\":\"Dolorem nemo debitis\"},\"old\":{\"student_id\":6,\"short_description\":null,\"outcome\":\"Dolorem nemo debitis\"}}',NULL,'2023-08-23 03:25:12','2023-08-23 03:25:12'),(67,'default','updated','App\\Models\\Anecdotal','updated',46,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Reissdsada\",\"outcome\":\"Dolorem nemo debitis\"},\"old\":{\"student_id\":6,\"short_description\":\"Reissdsada\",\"outcome\":\"Dolorem nemo debitis\"}}',NULL,'2023-08-23 03:30:28','2023-08-23 03:30:28'),(68,'default','updated','App\\Models\\Anecdotal','updated',46,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Reissdsada\",\"outcome\":\"Dolorem nemo debitis\"},\"old\":{\"student_id\":1,\"short_description\":\"Reissdsada\",\"outcome\":\"Dolorem nemo debitis\"}}',NULL,'2023-08-23 03:32:13','2023-08-23 03:32:13'),(69,'default','updated','App\\Models\\Anecdotal','updated',46,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Reissdsada\",\"outcome\":\"Dolorem nemo debitis\"},\"old\":{\"student_id\":6,\"short_description\":\"Reissdsada\",\"outcome\":\"Dolorem nemo debitis\"}}',NULL,'2023-08-23 03:33:08','2023-08-23 03:33:08'),(70,'default','updated','App\\Models\\Anecdotal','updated',46,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Reissdsada\",\"outcome\":\"Dolorem nemo debitis\"},\"old\":{\"student_id\":1,\"short_description\":\"Reissdsada\",\"outcome\":\"Dolorem nemo debitis\"}}',NULL,'2023-08-23 03:33:15','2023-08-23 03:33:15'),(71,'default','updated','App\\Models\\Anecdotal','updated',46,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Reissdsada\",\"outcome\":\"Dolorem nemo debitis\"},\"old\":{\"student_id\":1,\"short_description\":\"Reissdsada\",\"outcome\":\"Dolorem nemo debitis\"}}',NULL,'2023-08-23 03:33:31','2023-08-23 03:33:31'),(72,'default','updated','App\\Models\\Anecdotal','updated',46,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Reissdsada\",\"outcome\":\"Dolorem nemo debitis\"},\"old\":{\"student_id\":1,\"short_description\":\"Reissdsada\",\"outcome\":\"Dolorem nemo debitis\"}}',NULL,'2023-08-23 03:33:54','2023-08-23 03:33:54'),(73,'default','created','App\\Models\\Anecdotal','created',49,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Est consequatur Mol\",\"outcome\":\"Dolores ullamco nemo\"}}',NULL,'2023-08-23 03:42:17','2023-08-23 03:42:17'),(74,'default','updated','App\\Models\\Anecdotal','updated',49,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Est consequatur Mol\",\"outcome\":\"Dolores ullamco nemo\"},\"old\":{\"student_id\":6,\"short_description\":\"Est consequatur Mol\",\"outcome\":\"Dolores ullamco nemo\"}}',NULL,'2023-08-23 19:29:15','2023-08-23 19:29:15'),(75,'default','created','App\\Models\\Anecdotal','created',50,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Magna occaecat do do\",\"outcome\":\"Voluptas delectus d\"}}',NULL,'2023-08-26 03:40:55','2023-08-26 03:40:55'),(76,'default','updated','App\\Models\\Anecdotal','updated',50,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":6,\"short_description\":\"Magna occaecat do do\",\"outcome\":\"Voluptas delectus d\"},\"old\":{\"student_id\":6,\"short_description\":\"Magna occaecat do do\",\"outcome\":\"Voluptas delectus d\"}}',NULL,'2023-08-26 03:41:23','2023-08-26 03:41:23'),(77,'default','created','App\\Models\\Anecdotal','created',51,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"Amet aut molestiae \"}}',NULL,'2023-08-26 18:33:47','2023-08-26 18:33:47'),(78,'default','updated','App\\Models\\User','updated',2,'App\\Models\\User',2,'{\"attributes\":{\"name\":\"Adviser Akira\",\"email\":\"adviser@gmail.com\",\"password\":\"$2y$10$qki9cfjZwzE0ZSNtJGLj9.KH0yh0FQDzSIRb.i2d.eGy7NktKjCC6\"},\"old\":{\"name\":\"Adviser\",\"email\":\"adviser@gmail.com\",\"password\":\"$2y$10$qki9cfjZwzE0ZSNtJGLj9.KH0yh0FQDzSIRb.i2d.eGy7NktKjCC6\"}}',NULL,'2023-08-26 18:56:21','2023-08-26 18:56:21'),(79,'default','created','App\\Models\\User','created',3,NULL,NULL,'{\"attributes\":{\"name\":\"User\",\"email\":\"user@gmail.com\",\"password\":\"$2y$10$Ky9Uf1Ch65N2sqAkkTxR6OeHWmhn10eIPWXXEmD3sCv7mh6oFi6aa\"}}',NULL,'2023-08-29 11:50:57','2023-08-29 11:50:57'),(80,'default','created','App\\Models\\User','created',4,NULL,NULL,'{\"attributes\":{\"name\":\"Dana Herman\",\"email\":\"gusaxywulu@mailinator.com\",\"password\":\"$2y$10$tcs7mmwDIAqY78WTAg1bGOd9tBtWnvKtknwBJwQkEVODC\\/t\\/KnaUi\"}}',NULL,'2023-08-29 11:52:47','2023-08-29 11:52:47'),(81,'default','created','App\\Models\\Anecdotal','created',52,'App\\Models\\User',4,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"Et enim dolores pers\"}}',NULL,'2023-08-29 12:01:26','2023-08-29 12:01:26'),(82,'default','updated','App\\Models\\Anecdotal','updated',52,'App\\Models\\User',1,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"Et enim dolores pers\"},\"old\":{\"student_id\":1,\"short_description\":\"Doloremque culpa es\",\"outcome\":\"Et enim dolores pers\"}}',NULL,'2023-08-29 12:39:35','2023-08-29 12:39:35'),(83,'default','created','App\\Models\\Anecdotal','created',53,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":19,\"short_description\":\"Aut itaque dolor hic\",\"outcome\":\"Elit sunt sit non \"}}',NULL,'2023-08-29 23:30:31','2023-08-29 23:30:31'),(84,'default','created','App\\Models\\User','created',5,NULL,NULL,'{\"attributes\":{\"name\":\"Yvonne Stout\",\"email\":\"vycugone@mailinator.com\",\"password\":\"$2y$10$mndifwIGxGqo46xKo9VPM.F4AxZAZM.N8i0xTywAkRtAu\\/1aggkdu\"}}',NULL,'2023-08-29 23:35:19','2023-08-29 23:35:19'),(85,'default','created','App\\Models\\Anecdotal','created',54,'App\\Models\\User',5,'{\"attributes\":{\"student_id\":1,\"short_description\":\"A quidem enim aliqui\",\"outcome\":\"Animi velit minus \"}}',NULL,'2023-08-29 23:35:31','2023-08-29 23:35:31'),(86,'default','updated','App\\Models\\Anecdotal','updated',54,'App\\Models\\User',5,'{\"attributes\":{\"student_id\":1,\"short_description\":\"A quidem enim aliqui\",\"outcome\":\"Animi velit minus \"},\"old\":{\"student_id\":1,\"short_description\":\"A quidem enim aliqui\",\"outcome\":\"Animi velit minus \"}}',NULL,'2023-08-29 23:35:53','2023-08-29 23:35:53'),(87,'default','created','App\\Models\\Anecdotal','created',55,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Illo labore excepteu\",\"outcome\":\"Est aut veritatis qu\"}}',NULL,'2023-08-29 23:37:08','2023-08-29 23:37:08'),(88,'default','updated','App\\Models\\User','updated',1,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"Adminn\",\"email\":\"admin@gmail.com\",\"password\":\"$2y$10$SluAl.JKpB71YT8wzNp9k.FnSemU2v3BEdbjgKWrkDKg6aHes11iC\"},\"old\":{\"name\":\"Admin\",\"email\":\"admin@gmail.com\",\"password\":\"$2y$10$SluAl.JKpB71YT8wzNp9k.FnSemU2v3BEdbjgKWrkDKg6aHes11iC\"}}',NULL,'2023-08-30 02:46:05','2023-08-30 02:46:05'),(89,'default','updated','App\\Models\\User','updated',1,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"Admin\",\"email\":\"admin@gmail.com\",\"password\":\"$2y$10$SluAl.JKpB71YT8wzNp9k.FnSemU2v3BEdbjgKWrkDKg6aHes11iC\"},\"old\":{\"name\":\"Adminn\",\"email\":\"admin@gmail.com\",\"password\":\"$2y$10$SluAl.JKpB71YT8wzNp9k.FnSemU2v3BEdbjgKWrkDKg6aHes11iC\"}}',NULL,'2023-08-30 02:49:37','2023-08-30 02:49:37'),(90,'default','created','App\\Models\\User','created',6,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"Excepteur iusto ut i\",\"email\":\"penig@mailinator.com\",\"password\":\"Pa$$w0rd!\"}}',NULL,'2023-08-30 03:24:49','2023-08-30 03:24:49'),(91,'default','created','App\\Models\\User','created',7,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"Admin Aki\",\"email\":\"lyhuf@mailinator.com\",\"password\":\"Pa$$w0rd!\"}}',NULL,'2023-08-30 03:28:43','2023-08-30 03:28:43'),(92,'default','created','App\\Models\\User','created',8,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"Teacher\",\"email\":\"akireiss@gmail.com\",\"password\":\"Pa$$w0rd!\"}}',NULL,'2023-08-30 03:29:23','2023-08-30 03:29:23'),(93,'default','created','App\\Models\\User','created',9,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"Et iusto voluptatem\",\"email\":\"pafineh@mailinator.com\",\"password\":\"Pa$$w0rd!\"}}',NULL,'2023-08-30 03:32:39','2023-08-30 03:32:39'),(94,'default','created','App\\Models\\User','created',10,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"Ad distinctio Ipsum\",\"email\":\"hovilifico@mailinator.com\",\"password\":\"Pa$$w0rd!\"}}',NULL,'2023-08-30 03:32:51','2023-08-30 03:32:51'),(95,'default','created','App\\Models\\User','created',11,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"Libero aliquid quibu\",\"email\":\"hygufelo@mailinator.com\",\"password\":\"Pa$$w0rd!\"}}',NULL,'2023-08-30 03:33:02','2023-08-30 03:33:02'),(96,'default','created','App\\Models\\User','created',12,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"Omnis do adipisci qu\",\"email\":\"hologifyl@mailinator.com\",\"password\":\"Pa$$w0rd!\"}}',NULL,'2023-08-30 03:33:13','2023-08-30 03:33:13'),(97,'default','created','App\\Models\\User','created',13,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"adasd\",\"email\":\"dsadas@gmail.com\",\"password\":\"sadasdaddasd\"}}',NULL,'2023-08-30 13:50:36','2023-08-30 13:50:36'),(98,'default','created','App\\Models\\User','created',14,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"Akira\",\"email\":\"reiss@gmail.com\",\"password\":\"fsdfdsfsddsfsffsdfsdf\"}}',NULL,'2023-08-30 13:57:36','2023-08-30 13:57:36'),(99,'default','updated','App\\Models\\User','updated',1,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"Admin\",\"email\":\"admin@gmail.com\",\"password\":\"$2y$10$A0fgeATNmEdYilZ\\/FPushOhzULp85RY17s.WsQx\\/z48rCixCEzLI6\"},\"old\":{\"name\":\"Admin\",\"email\":\"admin@gmail.com\",\"password\":\"$2y$10$SluAl.JKpB71YT8wzNp9k.FnSemU2v3BEdbjgKWrkDKg6aHes11iC\"}}',NULL,'2023-08-30 14:14:32','2023-08-30 14:14:32'),(100,'default','updated','App\\Models\\User','updated',1,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"Admin Akira\",\"email\":\"admin@gmail.com\",\"password\":\"$2y$10$A0fgeATNmEdYilZ\\/FPushOhzULp85RY17s.WsQx\\/z48rCixCEzLI6\"},\"old\":{\"name\":\"Admin\",\"email\":\"admin@gmail.com\",\"password\":\"$2y$10$A0fgeATNmEdYilZ\\/FPushOhzULp85RY17s.WsQx\\/z48rCixCEzLI6\"}}',NULL,'2023-08-30 14:18:57','2023-08-30 14:18:57'),(101,'default','updated','App\\Models\\User','updated',1,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"Admin Akira\",\"email\":\"admin@gmail.com\",\"password\":\"$2y$10$WbOGXlP8ftEoneZB7KutdOuawavpc.qBDqsBbWWri7SQ4ziKDo.pe\"},\"old\":{\"name\":\"Admin Akira\",\"email\":\"admin@gmail.com\",\"password\":\"$2y$10$A0fgeATNmEdYilZ\\/FPushOhzULp85RY17s.WsQx\\/z48rCixCEzLI6\"}}',NULL,'2023-08-30 14:20:06','2023-08-30 14:20:06'),(102,'default','updated','App\\Models\\User','updated',1,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"Admin Akira\",\"email\":\"admin@gmail.com\",\"password\":\"$2y$10$jk57pl6\\/d5H1N2vMT2kMRuYi8PK2uxUt7Z\\/ZXrJdvUP2kWcpqKgwW\"},\"old\":{\"name\":\"Admin Akira\",\"email\":\"admin@gmail.com\",\"password\":\"$2y$10$WbOGXlP8ftEoneZB7KutdOuawavpc.qBDqsBbWWri7SQ4ziKDo.pe\"}}',NULL,'2023-08-30 14:20:39','2023-08-30 14:20:39'),(103,'default','created','App\\Models\\User','created',15,NULL,NULL,'{\"attributes\":{\"name\":\"Joshua Ledda\",\"email\":\"joshua.ledda@student.dmmmsu.edu.ph\",\"password\":\"$2y$10$rKdyj4df0aNbd8so5onQKueq3hP0srbOa4CFhtDJ.WHUdhMsao3Mm\"}}',NULL,'2023-08-30 19:12:43','2023-08-30 19:12:43'),(104,'default','updated','App\\Models\\User','updated',15,NULL,NULL,'{\"attributes\":{\"name\":\"Joshua Ledda\",\"email\":\"joshua.ledda@student.dmmmsu.edu.ph\",\"password\":\"$2y$10$UdHVFBxPUSxMjSpO0ApKIeDwaIDaorgQAHiNrzchG2AQ.al013ygi\"},\"old\":{\"name\":\"Joshua Ledda\",\"email\":\"joshua.ledda@student.dmmmsu.edu.ph\",\"password\":\"$2y$10$rKdyj4df0aNbd8so5onQKueq3hP0srbOa4CFhtDJ.WHUdhMsao3Mm\"}}',NULL,'2023-08-30 19:20:21','2023-08-30 19:20:21'),(105,'default','updated','App\\Models\\User','updated',15,'App\\Models\\User',15,'{\"attributes\":{\"name\":\"Joshua Ledda\",\"email\":\"joshua.ledda@student.dmmmsu.edu.ph\",\"password\":\"$2y$10$UdHVFBxPUSxMjSpO0ApKIeDwaIDaorgQAHiNrzchG2AQ.al013ygi\"},\"old\":{\"name\":\"Joshua Ledda\",\"email\":\"joshua.ledda@student.dmmmsu.edu.ph\",\"password\":\"$2y$10$UdHVFBxPUSxMjSpO0ApKIeDwaIDaorgQAHiNrzchG2AQ.al013ygi\"}}',NULL,'2023-08-30 19:23:23','2023-08-30 19:23:23'),(106,'default','updated','App\\Models\\User','updated',15,NULL,NULL,'{\"attributes\":{\"name\":\"Joshua Ledda\",\"email\":\"joshua.ledda@student.dmmmsu.edu.ph\",\"password\":\"$2y$10$GPMkPbyPjgJkHBUmu2pzOuhlZXhNozSQNOPODqT7dZ5oP.qJ9hSIq\"},\"old\":{\"name\":\"Joshua Ledda\",\"email\":\"joshua.ledda@student.dmmmsu.edu.ph\",\"password\":\"$2y$10$UdHVFBxPUSxMjSpO0ApKIeDwaIDaorgQAHiNrzchG2AQ.al013ygi\"}}',NULL,'2023-08-30 19:24:06','2023-08-30 19:24:06'),(107,'default','updated','App\\Models\\User','updated',15,'App\\Models\\User',15,'{\"attributes\":{\"name\":\"Joshua Ledda\",\"email\":\"joshua.ledda@student.dmmmsu.edu.ph\",\"password\":\"$2y$10$GPMkPbyPjgJkHBUmu2pzOuhlZXhNozSQNOPODqT7dZ5oP.qJ9hSIq\"},\"old\":{\"name\":\"Joshua Ledda\",\"email\":\"joshua.ledda@student.dmmmsu.edu.ph\",\"password\":\"$2y$10$GPMkPbyPjgJkHBUmu2pzOuhlZXhNozSQNOPODqT7dZ5oP.qJ9hSIq\"}}',NULL,'2023-08-30 19:32:43','2023-08-30 19:32:43'),(108,'default','updated','App\\Models\\User','updated',1,'App\\Models\\User',1,'{\"attributes\":{\"name\":\"Admin Akira\",\"email\":\"admin@gmail.com\",\"password\":\"$2y$10$Tps4Q6AQVgHen5UglurkFudy4OjDo9x9al4oAnbFE0FGfdloScvzm\"},\"old\":{\"name\":\"Admin Akira\",\"email\":\"admin@gmail.com\",\"password\":\"$2y$10$jk57pl6\\/d5H1N2vMT2kMRuYi8PK2uxUt7Z\\/ZXrJdvUP2kWcpqKgwW\"}}',NULL,'2023-09-01 22:10:17','2023-09-01 22:10:17'),(109,'default','created','App\\Models\\Anecdotal','created',56,'App\\Models\\User',2,'{\"attributes\":{\"student_id\":19,\"short_description\":\"Id veritatis tempori\",\"outcome\":\"Porro possimus vita\"}}',NULL,'2023-09-02 00:32:10','2023-09-02 00:32:10'),(110,'default','created','App\\Models\\User','created',16,NULL,NULL,'{\"attributes\":{\"name\":\"Cooper Pena\",\"email\":\"hehiwel@mailinator.com\",\"password\":\"$2y$10$HZyFRKxMLR.Rha4UsN8YsuD.LWo9RyuEwJadj5vFqME0U8evQAtcu\"}}',NULL,'2023-09-02 07:51:27','2023-09-02 07:51:27'),(111,'default','created','App\\Models\\Anecdotal','created',57,'App\\Models\\User',16,'{\"attributes\":{\"student_id\":1,\"short_description\":\"Nihil duis magni id \",\"outcome\":\"Id est sit ipsa in\"}}',NULL,'2023-09-02 07:51:43','2023-09-02 07:51:43'),(112,'default','created','App\\Models\\Anecdotal','created',58,'App\\Models\\User',16,'{\"attributes\":{\"student_id\":3,\"short_description\":\"Voluptas duis tempor\",\"outcome\":\"Facere exercitation \"}}',NULL,'2023-09-02 07:51:56','2023-09-02 07:51:56');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `anecdotal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `anecdotal` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `offense_id` bigint(20) unsigned NOT NULL,
  `gravity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_description` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observation` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `desired` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `outcome` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `letter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `case_status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0:pending | 1: accept | 2: inprogress | 3: closed',
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0:active | 1:inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `anecdotal_student_id_foreign` (`student_id`),
  KEY `anecdotal_offense_id_foreign` (`offense_id`),
  CONSTRAINT `anecdotal_offense_id_foreign` FOREIGN KEY (`offense_id`) REFERENCES `offenses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `anecdotal_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `anecdotal` WRITE;
/*!40000 ALTER TABLE `anecdotal` DISABLE KEYS */;
INSERT INTO `anecdotal` VALUES (46,1,8,'1','Reissdsada','Quasi sint ut dolor ','Akira','Dolorem nemo debitis','uploads/378BJNakAkQjyLWlmnPD1BXI3Rvkl8Qch2V7GzrB.png',2,0,'2023-10-18 17:51:30','2023-08-10 03:33:54'),(47,1,7,'0','Sapiente qui in volu','Reprehenderit sed si','Ut fuga Voluptas es','Et dignissimos ipsum',NULL,1,0,'2023-08-22 17:53:43','2023-08-22 17:53:43'),(48,6,7,'2','Velit qui commodo in','Eum sint labore sed ','Ab quis qui omnis of','Qui perferendis duis',NULL,1,0,'2023-08-01 17:58:30','2023-08-22 17:58:30'),(49,6,1,'2','Est consequatur Mol','Occaecat quo in quia','Laudantium quasi mo','Dolores ullamco nemo',NULL,2,0,'2023-08-01 03:42:17','2023-08-23 19:29:15'),(50,6,3,'4','Magna occaecat do do','Aliquam dolores ut i','Maxime quasi sapient','Voluptas delectus d',NULL,1,0,'2023-08-26 03:40:55','2023-08-26 03:41:23'),(51,1,5,'2','Doloremque culpa es','Officiis facere reru','Nostrum eligendi et ','Amet aut molestiae ',NULL,0,0,'2023-08-26 18:33:47','2023-08-26 18:33:47'),(52,1,3,'1','Doloremque culpa es','Officiis facere reru','Nostrum eligendi et ','Et enim dolores pers',NULL,1,0,'2023-08-29 12:01:25','2023-08-29 12:39:35'),(53,19,5,'4','Aut itaque dolor hic','Magni dicta eaque fu','Sit voluptatem et ex','Elit sunt sit non ',NULL,0,0,'2023-08-29 23:30:31','2023-08-29 23:30:31'),(54,1,6,'3','A quidem enim aliqui','dsadsa','Ex rerum impedit de','Animi velit minus ',NULL,0,0,'2023-08-29 23:35:31','2023-08-29 23:35:53'),(55,1,1,'2','Illo labore excepteu','Fugiat alias est li','Et alias sapiente no','Est aut veritatis qu',NULL,0,0,'2023-08-29 23:37:08','2023-08-29 23:37:08'),(56,19,3,'3','Id veritatis tempori','Aut impedit accusam','Adipisci ea sint se','Porro possimus vita',NULL,0,0,'2023-09-02 00:32:10','2023-09-02 00:32:10'),(57,1,6,'2','Nihil duis magni id ','Quis proident sunt ','Ad dolore sunt nemo ','Id est sit ipsa in',NULL,0,0,'2023-09-02 07:51:43','2023-09-02 07:51:43'),(58,3,3,'2','Voluptas duis tempor','Dolores libero ad ad','In officia et suscip','Facere exercitation ',NULL,0,0,'2023-09-02 07:51:56','2023-09-02 07:51:56');
/*!40000 ALTER TABLE `anecdotal` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `anecdotal_outcome`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `anecdotal_outcome` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `anecdotal_id` bigint(20) unsigned NOT NULL,
  `actions_id` bigint(20) unsigned DEFAULT NULL,
  `outcome` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `outcome_remarks` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `anecdotal_outcome_anecdotal_id_foreign` (`anecdotal_id`),
  KEY `anecdotal_outcome_actions_id_foreign` (`actions_id`),
  CONSTRAINT `anecdotal_outcome_actions_id_foreign` FOREIGN KEY (`actions_id`) REFERENCES `actions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `anecdotal_outcome_anecdotal_id_foreign` FOREIGN KEY (`anecdotal_id`) REFERENCES `anecdotal` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `anecdotal_outcome` WRITE;
/*!40000 ALTER TABLE `anecdotal_outcome` DISABLE KEYS */;
INSERT INTO `anecdotal_outcome` VALUES (14,46,NULL,NULL,NULL,'2023-08-22 17:51:31','2023-08-22 17:51:31'),(15,47,NULL,'','','2023-08-22 17:53:43','2023-08-23 19:29:02'),(16,48,NULL,NULL,NULL,'2023-08-22 17:58:30','2023-08-22 17:58:30'),(17,49,NULL,NULL,NULL,'2023-08-23 03:42:17','2023-08-23 03:42:17'),(18,50,NULL,NULL,NULL,'2023-08-26 03:40:55','2023-08-26 03:40:55'),(19,51,NULL,NULL,NULL,'2023-08-26 18:33:47','2023-08-26 18:33:47'),(20,52,NULL,NULL,NULL,'2023-08-29 12:01:26','2023-08-29 12:01:26'),(21,53,NULL,NULL,NULL,'2023-08-29 23:30:31','2023-08-29 23:30:31'),(22,54,NULL,NULL,NULL,'2023-08-29 23:35:31','2023-08-29 23:35:31'),(23,55,NULL,NULL,NULL,'2023-08-29 23:37:08','2023-08-29 23:37:08'),(24,56,NULL,NULL,NULL,'2023-09-02 00:32:10','2023-09-02 00:32:10'),(25,57,NULL,NULL,NULL,'2023-09-02 07:51:43','2023-09-02 07:51:43'),(26,58,NULL,NULL,NULL,'2023-09-02 07:51:56','2023-09-02 07:51:56');
/*!40000 ALTER TABLE `anecdotal_outcome` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `awards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `awards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profile_id` bigint(20) unsigned DEFAULT NULL,
  `award_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `award_year` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `awards_profile_id_foreign` (`profile_id`),
  CONSTRAINT `awards_profile_id_foreign` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `awards` WRITE;
/*!40000 ALTER TABLE `awards` DISABLE KEYS */;
INSERT INTO `awards` VALUES (3,NULL,'Modi enim voluptatem',43,'2023-08-23 19:30:39','2023-08-23 19:30:39'),(7,NULL,'Tenetur occaecat nob',19,'2023-08-24 18:01:24','2023-08-24 18:01:24'),(16,NULL,'First update',1111,'2023-08-25 00:50:28','2023-08-25 07:35:48'),(22,NULL,'second',9999,'2023-08-25 07:31:10','2023-08-25 07:36:10'),(23,NULL,'Sapiente nisi rerum ',10,'2023-08-25 18:07:20','2023-08-25 18:07:20'),(24,NULL,'Joshua Ledda',222,'2023-08-26 03:42:24','2023-08-26 03:42:24'),(25,NULL,'Amet quos non offic',72,'2023-08-26 04:01:49','2023-08-26 04:01:49'),(26,NULL,'Officia velit magna',29,'2023-08-26 04:09:04','2023-08-26 04:09:04'),(27,NULL,'Quisquam exercitatio',13,'2023-08-26 04:10:16','2023-08-26 04:10:16'),(28,NULL,'Odio exercitation re',6,'2023-08-26 04:12:35','2023-08-26 04:12:35'),(29,NULL,'Qui cupidatat consec',29,'2023-08-26 04:16:18','2023-08-26 04:16:18'),(30,NULL,'Ut et aute tempore ',45,'2023-08-26 04:47:00','2023-08-26 04:47:00'),(31,NULL,'Voluptas ab sit dolo',64,'2023-08-26 04:48:17','2023-08-26 04:48:17'),(32,NULL,'Ut ex in atque in si',28,'2023-08-26 05:27:21','2023-08-26 05:27:21'),(33,NULL,'Qui odio odio do in ',56,'2023-08-26 05:28:26','2023-08-26 05:28:26'),(34,NULL,'Id dolores consequun',13,'2023-08-26 05:40:02','2023-08-26 05:40:02'),(35,NULL,'Rem velit cillum aut',44,'2023-08-26 05:45:05','2023-08-26 05:45:05'),(36,NULL,'Mollitia sit commodi',58,'2023-09-02 08:11:23','2023-09-02 08:11:23'),(37,NULL,'Mollitia sit commodi',58,'2023-09-02 08:11:33','2023-09-02 08:11:33'),(38,NULL,'Mollitia sit commodi',58,'2023-09-02 08:11:48','2023-09-02 08:11:48'),(39,NULL,'Mollitia sit commodi',58,'2023-09-02 08:11:58','2023-09-02 08:11:58'),(40,NULL,'Mollitia sit commodi',58,'2023-09-02 08:12:12','2023-09-02 08:12:12'),(41,NULL,'Mollitia sit commodi',58,'2023-09-02 08:12:13','2023-09-02 08:12:13'),(42,NULL,'Mollitia sit commodi',58,'2023-09-02 08:12:14','2023-09-02 08:12:14'),(43,NULL,'Mollitia sit commodi',58,'2023-09-02 08:12:15','2023-09-02 08:12:15'),(44,NULL,'Mollitia sit commodi',58,'2023-09-02 08:12:16','2023-09-02 08:12:16'),(45,NULL,'Mollitia sit commodi',58,'2023-09-02 08:12:48','2023-09-02 08:12:48'),(46,NULL,'Mollitia sit commodi',58,'2023-09-02 08:13:11','2023-09-02 08:13:11'),(47,NULL,'Neque laboris deseru',90,'2023-09-02 08:14:20','2023-09-02 08:14:20'),(48,NULL,'Quisquam dolorem bla',36,'2023-09-02 08:19:26','2023-09-02 08:19:26'),(49,NULL,'Quisquam dolorem bla',36,'2023-09-02 08:19:40','2023-09-02 08:19:40'),(50,NULL,'Quisquam dolorem bla',36,'2023-09-02 08:19:41','2023-09-02 08:19:41'),(51,NULL,'Quisquam dolorem bla',36,'2023-09-02 08:19:42','2023-09-02 08:19:42'),(52,NULL,'Quisquam dolorem bla',36,'2023-09-02 08:19:43','2023-09-02 08:19:43'),(53,NULL,'Quisquam dolorem bla',36,'2023-09-02 08:19:44','2023-09-02 08:19:44'),(54,NULL,'Quisquam dolorem bla',36,'2023-09-02 08:19:45','2023-09-02 08:19:45'),(55,NULL,'Quisquam dolorem bla',36,'2023-09-02 08:20:42','2023-09-02 08:20:42'),(56,NULL,'Quisquam dolorem bla',36,'2023-09-02 08:20:50','2023-09-02 08:20:50'),(57,NULL,'Quisquam dolorem bla',36,'2023-09-02 08:21:09','2023-09-02 08:21:09'),(58,NULL,'Quisquam dolorem bla',36,'2023-09-02 08:21:11','2023-09-02 08:21:11'),(59,NULL,'Fuga Obcaecati enim',29,'2023-09-02 08:27:41','2023-09-02 08:27:41'),(60,NULL,'Accusantium dolores ',80,'2023-09-02 08:34:50','2023-09-02 08:34:50'),(61,NULL,'Voluptatum et sit d',11,'2023-09-02 08:45:44','2023-09-02 08:45:44'),(62,NULL,'Eos assumenda aliqua',87,'2023-09-02 08:47:38','2023-09-02 08:47:38'),(63,57,'Aperiam quod tempore',41,'2023-09-02 08:50:17','2023-09-02 08:50:17'),(64,58,'Aut optio exercitat',97,'2023-09-02 08:56:33','2023-09-02 08:56:33');
/*!40000 ALTER TABLE `awards` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `barangay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `barangay` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `barangay` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `municipal_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `barangay_municipal_id_foreign` (`municipal_id`),
  CONSTRAINT `barangay_municipal_id_foreign` FOREIGN KEY (`municipal_id`) REFERENCES `municipal` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `barangay` WRITE;
/*!40000 ALTER TABLE `barangay` DISABLE KEYS */;
INSERT INTO `barangay` VALUES (1,'Butubut Norte',1,NULL,NULL),(2,'Butubut Sur',1,NULL,NULL),(3,'Paraoir',1,NULL,NULL),(4,'Nagbagyan',3,NULL,NULL),(5,'Baybay',2,NULL,NULL),(6,'Supin',4,NULL,NULL);
/*!40000 ALTER TABLE `barangay` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `classrooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classrooms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `grade_level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_id` bigint(20) unsigned NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `classrooms_employee_id_foreign` (`employee_id`),
  CONSTRAINT `classrooms_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `classrooms` WRITE;
/*!40000 ALTER TABLE `classrooms` DISABLE KEYS */;
INSERT INTO `classrooms` VALUES (1,'8','Jupiter',1,'0','2023-08-19 16:54:36','2023-08-19 16:54:36'),(2,'9','Sun',1,'0',NULL,NULL);
/*!40000 ALTER TABLE `classrooms` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `education_background`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `education_background` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `profile_id` bigint(20) unsigned NOT NULL,
  `school_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `school_year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grade_section` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grade_level` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `education_background_profile_id_foreign` (`profile_id`),
  CONSTRAINT `education_background_profile_id_foreign` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=295 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `education_background` WRITE;
/*!40000 ALTER TABLE `education_background` DISABLE KEYS */;
INSERT INTO `education_background` VALUES (283,'2023-09-02 08:50:17','2023-09-02 08:50:17',57,'Carter Molina','2017','Obcaecati nobis aut ',7),(284,'2023-09-02 08:50:17','2023-09-02 08:50:17',57,'Octavia Whitney','1996','Hic nulla sunt ullam',8),(285,'2023-09-02 08:50:17','2023-09-02 08:50:17',57,'Deacon Houston','1987','Similique et quia do',9),(286,'2023-09-02 08:50:17','2023-09-02 08:50:17',57,'Cedric Jennings','2012','Nulla et rerum in qu',10),(287,'2023-09-02 08:50:17','2023-09-02 08:50:17',57,'Madonna Patrick','2015','Quae ipsam dolor dol',11),(288,'2023-09-02 08:50:17','2023-09-02 08:50:17',57,'John Quinn','2013','Animi adipisicing o',12),(289,'2023-09-02 08:56:33','2023-09-02 08:56:33',58,'Talon Fry','2006','Hic ex ducimus sed ',7),(290,'2023-09-02 08:56:33','2023-09-02 08:56:33',58,'Silas Powell','1972','Illo eligendi veniam',8),(291,'2023-09-02 08:56:33','2023-09-02 08:56:33',58,'Glenna Grant','1988','Sapiente magnam veni',9),(292,'2023-09-02 08:56:33','2023-09-02 08:56:33',58,'Travis Lancaster','1971','Dolor ut eaque exerc',10),(293,'2023-09-02 08:56:33','2023-09-02 08:56:33',58,'Hedda Duke','1982','Aut harum labore eve',11),(294,'2023-09-02 08:56:33','2023-09-02 08:56:33',58,'Rylee Farmer','1985','Minus magna dolore h',12);
/*!40000 ALTER TABLE `education_background` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `employees` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `refference_number` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0:active | 1:inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'Joshua Ledda',21313123,0,'2023-08-19 16:54:01','2023-08-28 00:47:33'),(2,'Reiss Akira',123123223,0,'2023-08-26 18:16:57','2023-08-26 18:16:57'),(3,'Voluptas ut ea moles',3141212,0,'2023-08-26 18:18:14','2023-08-26 18:18:14');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `medicines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medicines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profile_id` bigint(20) unsigned NOT NULL,
  `medicine` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `medicines_profile_id_foreign` (`profile_id`),
  CONSTRAINT `medicines_profile_id_foreign` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=162 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `medicines` WRITE;
/*!40000 ALTER TABLE `medicines` DISABLE KEYS */;
INSERT INTO `medicines` VALUES (156,57,'Aut voluptatem exerc','2023-09-02 08:50:17','2023-09-02 08:50:17'),(157,57,'Sint non exercitatio','2023-09-02 08:50:17','2023-09-02 08:50:17'),(158,57,'Expedita fugiat ips','2023-09-02 08:50:17','2023-09-02 08:50:17'),(159,58,'Beatae voluptas mole','2023-09-02 08:56:33','2023-09-02 08:56:33'),(160,58,'Reprehenderit volupt','2023-09-02 08:56:33','2023-09-02 08:56:33'),(161,58,'Sit quod nisi neces','2023-09-02 08:56:33','2023-09-02 08:56:33');
/*!40000 ALTER TABLE `medicines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_100000_create_password_reset_tokens_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2023_06_14_064839_create_offenses_table',1),(6,'2023_06_21_021328_create_employees_table',1),(7,'2023_06_24_155412_create_classrooms_table',1),(8,'2023_06_25_000000_create_users_table',1),(9,'2023_06_25_222724_create_students_table',1),(10,'2023_07_01_024908_create_activity_log_table',1),(11,'2023_07_01_024909_add_event_column_to_activity_log_table',1),(12,'2023_07_01_024910_add_batch_uuid_column_to_activity_log_table',1),(13,'2023_07_08_030914_create_anecdotal_table',1),(14,'2023_07_08_031227_create_reports_table',1),(15,'2023_07_08_031301_create_actions_taken_table',1),(16,'2023_07_11_020939_create_province_table',1),(17,'2023_07_11_021000_create_municipal_table',1),(18,'2023_07_11_021010_create_barangay_table',1),(19,'2023_07_11_021705_create_profile_table',1),(20,'2023_07_11_062525_create_parents_table',1),(21,'2023_07_14_061226_create_education_background_table',1),(22,'2023_07_14_063755_create_siblings_table',1),(23,'2023_07_14_064212_create_awards_table',1),(24,'2023_07_14_070649_create_parent_status_table',1),(25,'2023_07_14_070848_create_medicines_table',1),(26,'2023_07_14_070855_create_vitamins_table',1),(27,'2023_07_14_070906_create_accidents_table',1),(28,'2023_07_14_070915_create_operations_table',1),(29,'2023_08_07_021408_create_actions_table',1),(31,'2023_08_22_012516_create_anecdotal_outcome_table',2),(32,'2023_08_24_002302_add_column_to_education_background_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `municipal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `municipal` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `municipality` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `municipal_province_id_foreign` (`province_id`),
  CONSTRAINT `municipal_province_id_foreign` FOREIGN KEY (`province_id`) REFERENCES `province` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `municipal` WRITE;
/*!40000 ALTER TABLE `municipal` DISABLE KEYS */;
INSERT INTO `municipal` VALUES (1,'Balaoan',1,NULL,NULL),(2,'Luna',2,NULL,NULL),(3,'Bangar',1,NULL,NULL),(4,'Sudipen',1,NULL,NULL);
/*!40000 ALTER TABLE `municipal` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `offenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offenses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL COMMENT '0:minor | 1:grave',
  `offenses` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0:active | 1:inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `offenses` WRITE;
/*!40000 ALTER TABLE `offenses` DISABLE KEYS */;
INSERT INTO `offenses` VALUES (1,0,'Violationsadasd','Kiraira',1,NULL,'2023-08-28 01:46:37'),(2,1,'Smoking ','Smoking Smoking Again',0,NULL,NULL),(3,0,'Vandalism','dadsadadas',0,NULL,NULL),(4,1,'Defiance of authority','Defiance of authority afadfadadsadsad',0,NULL,NULL),(5,1,'Fighting','dsadsadad',0,NULL,NULL),(6,0,'Threatening ','Threatening ',0,NULL,NULL),(7,1,'Cyberbullying','',0,NULL,NULL),(8,0,'Stealing ','',0,NULL,NULL);
/*!40000 ALTER TABLE `offenses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profile_id` bigint(20) unsigned NOT NULL,
  `operations` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `operations_profile_id_foreign` (`profile_id`),
  CONSTRAINT `operations_profile_id_foreign` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `operations` WRITE;
/*!40000 ALTER TABLE `operations` DISABLE KEYS */;
INSERT INTO `operations` VALUES (142,57,'Fugiat qui in consec','2023-09-02 08:50:17','2023-09-02 08:50:17'),(143,57,'Est maiores porro ve','2023-09-02 08:50:17','2023-09-02 08:50:17'),(144,57,'Ea in laborum Non o','2023-09-02 08:50:17','2023-09-02 08:50:17'),(145,58,'Itaque quaerat saepe','2023-09-02 08:56:33','2023-09-02 08:56:33'),(146,58,'Nam non sunt sit ut','2023-09-02 08:56:33','2023-09-02 08:56:33'),(147,58,'Labore odio blanditi','2023-09-02 08:56:33','2023-09-02 08:56:33');
/*!40000 ALTER TABLE `operations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `parent_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parent_status` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profile_id` bigint(20) unsigned NOT NULL,
  `parent_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_status_profile_id_foreign` (`profile_id`),
  CONSTRAINT `parent_status_profile_id_foreign` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `parent_status` WRITE;
/*!40000 ALTER TABLE `parent_status` DISABLE KEYS */;
INSERT INTO `parent_status` VALUES (90,57,'Father is OFW','2023-09-02 08:50:17','2023-09-02 08:50:17'),(91,57,'Separated','2023-09-02 08:50:17','2023-09-02 08:50:17'),(92,58,'Separated','2023-09-02 08:56:33','2023-09-02 08:56:33');
/*!40000 ALTER TABLE `parent_status` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `parents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profile_id` bigint(20) unsigned NOT NULL,
  `parent_type` int(255) NOT NULL,
  `parent_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_age` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_occupation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_office_contact` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_birth_place` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_work_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_monthly_income` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parents_profile_id_foreign` (`profile_id`),
  CONSTRAINT `parents_profile_id_foreign` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `parents` WRITE;
/*!40000 ALTER TABLE `parents` DISABLE KEYS */;
INSERT INTO `parents` VALUES (95,57,0,'Magnam autem dolore ','59','Eum officia sint qui','92','Voluptatum nulla exp','Optio repudiandae a','Dolor optio duis el','97','2023-09-02 08:50:17','2023-09-02 08:50:17'),(96,57,1,'Amet sint iure mol','68','Nihil non eum consec','Ad aut in veniam pl','Id corporis incidunt','Aliquam anim laborio','Vero ut neque vel ea','71','2023-09-02 08:50:17','2023-09-02 08:50:17'),(97,58,0,'Fugiat nulla unde su','87','Expedita quae eum ea','88','Mollit aspernatur al','Dignissimos sapiente','Et blanditiis quo qu','26','2023-09-02 08:56:33','2023-09-02 08:56:33'),(98,58,1,'Voluptas numquam aut','7','Quia et ut quas irur','Proident eligendi m','In nulla libero sit','Nulla rerum cum vita','Provident optio ut','78','2023-09-02 08:56:33','2023-09-02 08:56:33');
/*!40000 ALTER TABLE `parents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
INSERT INTO `password_reset_tokens` VALUES ('admin@gmail.com','$2y$10$RxyyOOHsOAO/M.QhHbP.v.eTwxTqMiVlQuNrq0k.ck3YKJKG91j1C','2023-08-30 14:42:54'),('joshua.ledda@student.dmmmsu.edu.ph','$2y$10$o9QqiVj25LSfuNT3YFUWguPXeQxKk74tyWkM.swSo/9eNlweVIJ6i','2023-08-30 19:34:02');
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `suffix` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nickname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int(11) NOT NULL,
  `sex` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthdate` date NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `barangay_id` bigint(20) unsigned NOT NULL,
  `municipal_id` bigint(20) unsigned NOT NULL,
  `province_id` bigint(20) unsigned NOT NULL,
  `birth_place` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `religion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mother_tongue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `four_ps` tinyint(1) NOT NULL,
  `birth_order` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_of_siblings` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `living_with` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guardian_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guardian_relationship` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guardian_contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guardian_occupation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guardian_age` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guardian_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favorite_subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `difficult_subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `school_organization` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `graduation_plan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `height` decimal(8,2) DEFAULT NULL,
  `weight` decimal(8,2) DEFAULT NULL,
  `bmi` decimal(8,2) DEFAULT NULL,
  `disability` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `food_allergy` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `profile_student_id_foreign` (`student_id`),
  KEY `profile_barangay_id_foreign` (`barangay_id`),
  KEY `profile_municipal_id_foreign` (`municipal_id`),
  KEY `profile_province_id_foreign` (`province_id`),
  CONSTRAINT `profile_barangay_id_foreign` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`id`) ON DELETE CASCADE,
  CONSTRAINT `profile_municipal_id_foreign` FOREIGN KEY (`municipal_id`) REFERENCES `municipal` (`id`) ON DELETE CASCADE,
  CONSTRAINT `profile_province_id_foreign` FOREIGN KEY (`province_id`) REFERENCES `province` (`id`) ON DELETE CASCADE,
  CONSTRAINT `profile_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (57,17,'Quam sit exercitatio','Eu est officia offic',61,'Male','1993-05-02','Eligendi neque ex si',5,2,2,'Dolore pariatur Qui','Alias similique et c','Odit facilis digniss',0,'Eldest','Officia ut in volupt','both-parents','Perspiciatis molest','Suscipit architecto ','Culpa beatae tempor ',NULL,'36','Perspiciatis molest','Nostrum qui non reru','Dolor qui vel quo de','Ut dolore pariatur ','Work to help parents',87.00,18.00,98.00,'No','No','0','2023-09-02 08:50:16','2023-09-02 08:50:16'),(58,6,'Facere eu nostrum qu','Ut voluptatem eius v',51,'Male','1994-01-22','Distinctio Adipisci',1,1,1,'Proident reprehende','Et nulla incididunt ','Culpa mollit consec',1,'Youngest','Qui consectetur non ','father-only','Voluptatum culpa es','Veniam voluptatem s','Est ut repudiandae e',NULL,'72','Voluptatum culpa es','Dicta aut laborum Q','Eligendi nulla venia','Eum aliquid officia ','Work to help parents',37.00,70.00,41.00,'No','No','0','2023-09-02 08:56:33','2023-09-02 08:56:33');
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `province`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `province` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `province` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `province` WRITE;
/*!40000 ALTER TABLE `province` DISABLE KEYS */;
INSERT INTO `province` VALUES (1,'La Union',NULL,NULL),(2,'Luna',NULL,NULL);
/*!40000 ALTER TABLE `province` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `anecdotal_id` bigint(20) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0:active | 1:inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reports_anecdotal_id_foreign` (`anecdotal_id`),
  KEY `reports_user_id_foreign` (`user_id`),
  CONSTRAINT `reports_anecdotal_id_foreign` FOREIGN KEY (`anecdotal_id`) REFERENCES `anecdotal` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reports_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
INSERT INTO `reports` VALUES (51,2,55,0,'2023-08-29 23:37:08','2023-08-29 23:37:08'),(52,2,56,0,'2023-09-02 00:32:10','2023-09-02 00:32:10'),(53,16,57,0,'2023-09-02 07:51:43','2023-09-02 07:51:43'),(54,16,58,0,'2023-09-02 07:51:56','2023-09-02 07:51:56');
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `siblings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `siblings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profile_id` bigint(20) unsigned DEFAULT NULL,
  `sibling_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sibling_age` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sibling_grade_section` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `siblings_profile_id_foreign` (`profile_id`),
  CONSTRAINT `siblings_profile_id_foreign` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `siblings` WRITE;
/*!40000 ALTER TABLE `siblings` DISABLE KEYS */;
INSERT INTO `siblings` VALUES (6,NULL,'Veniam nisi dolorem','92','Animi amet rerum e','2023-08-23 19:30:39','2023-08-23 19:30:39'),(9,NULL,'Et proident delectu','5','Numquam quasi et quo','2023-08-24 18:01:24','2023-08-24 18:01:24'),(10,NULL,'Joshua','22','Ipsam autem in esse','2023-08-24 18:47:58','2023-08-25 07:37:23'),(19,NULL,'Reiss','11','Mai','2023-08-25 07:31:10','2023-08-25 07:37:23'),(20,NULL,'Josha LEdda','23','Jupiter','2023-08-25 17:12:59','2023-08-25 17:12:59'),(21,NULL,'Quidem culpa offici','78','Ipsa dolores sequi ','2023-08-25 18:07:20','2023-08-25 18:07:20'),(22,NULL,'Vel consequuntur sus','43','Optio hic non qui q','2023-08-26 04:01:49','2023-08-26 04:01:49'),(23,NULL,'Consectetur eos mol','20','Id fugiat illum eos','2023-08-26 04:09:04','2023-08-26 04:09:04'),(24,NULL,'Voluptatem autem hic','78','Aliquip ad velit cup','2023-08-26 04:10:16','2023-08-26 04:10:16'),(25,NULL,'Quis excepteur sed i','42','Ut culpa iste sit r','2023-08-26 04:12:35','2023-08-26 04:12:35'),(26,NULL,'Impedit et quo temp','65','Unde duis provident','2023-08-26 04:16:18','2023-08-26 04:16:18'),(27,NULL,'Vitae aperiam nulla ','9','Nulla est laboris vo','2023-08-26 04:47:00','2023-08-26 04:47:00'),(28,NULL,'Laborum sit eiusmod ','64','Sint tempora volupta','2023-08-26 04:48:17','2023-08-26 04:48:17'),(29,NULL,'Debitis perspiciatis','60','Pariatur Eos error','2023-08-26 05:27:21','2023-08-26 05:27:21'),(30,NULL,'Aut soluta et nostru','5','Doloremque rerum ad ','2023-08-26 05:28:26','2023-08-26 05:28:26'),(31,NULL,'Facere dolore saepe ','90','Adipisci possimus f','2023-08-26 05:40:02','2023-08-26 05:40:02'),(32,NULL,'Quidem dolores proid','30','In magnam pariatur ','2023-08-26 05:45:05','2023-08-26 05:45:05'),(33,NULL,'Reiss Mai','23','Potato','2023-08-29 23:31:56','2023-08-29 23:31:56'),(34,NULL,'Molestiae nobis unde','55','Iste exercitation te','2023-09-02 08:11:23','2023-09-02 08:11:23'),(35,NULL,'Molestiae nobis unde','55','Iste exercitation te','2023-09-02 08:11:33','2023-09-02 08:11:33'),(36,NULL,'Molestiae nobis unde','55','Iste exercitation te','2023-09-02 08:11:48','2023-09-02 08:11:48'),(37,NULL,'Molestiae nobis unde','55','Iste exercitation te','2023-09-02 08:11:58','2023-09-02 08:11:58'),(38,NULL,'Molestiae nobis unde','55','Iste exercitation te','2023-09-02 08:12:12','2023-09-02 08:12:12'),(39,NULL,'Molestiae nobis unde','55','Iste exercitation te','2023-09-02 08:12:13','2023-09-02 08:12:13'),(40,NULL,'Molestiae nobis unde','55','Iste exercitation te','2023-09-02 08:12:14','2023-09-02 08:12:14'),(41,NULL,'Molestiae nobis unde','55','Iste exercitation te','2023-09-02 08:12:15','2023-09-02 08:12:15'),(42,NULL,'Molestiae nobis unde','55','Iste exercitation te','2023-09-02 08:12:16','2023-09-02 08:12:16'),(43,NULL,'Molestiae nobis unde','55','Iste exercitation te','2023-09-02 08:12:48','2023-09-02 08:12:48'),(44,NULL,'Molestiae nobis unde','55','Iste exercitation te','2023-09-02 08:13:11','2023-09-02 08:13:11'),(45,NULL,'Qui est quis incidu','83','Est cum deserunt tem','2023-09-02 08:14:20','2023-09-02 08:14:20'),(46,NULL,'Sapiente error cum v','46','Voluptas dignissimos','2023-09-02 08:19:26','2023-09-02 08:19:26'),(47,NULL,'Sapiente error cum v','46','Voluptas dignissimos','2023-09-02 08:19:40','2023-09-02 08:19:40'),(48,NULL,'Sapiente error cum v','46','Voluptas dignissimos','2023-09-02 08:19:41','2023-09-02 08:19:41'),(49,NULL,'Sapiente error cum v','46','Voluptas dignissimos','2023-09-02 08:19:42','2023-09-02 08:19:42'),(50,NULL,'Sapiente error cum v','46','Voluptas dignissimos','2023-09-02 08:19:43','2023-09-02 08:19:43'),(51,NULL,'Sapiente error cum v','46','Voluptas dignissimos','2023-09-02 08:19:44','2023-09-02 08:19:44'),(52,NULL,'Sapiente error cum v','46','Voluptas dignissimos','2023-09-02 08:19:45','2023-09-02 08:19:45'),(53,NULL,'Sapiente error cum v','46','Voluptas dignissimos','2023-09-02 08:20:42','2023-09-02 08:20:42'),(54,NULL,'Sapiente error cum v','46','Voluptas dignissimos','2023-09-02 08:20:50','2023-09-02 08:20:50'),(55,NULL,'Sapiente error cum v','46','Voluptas dignissimos','2023-09-02 08:21:09','2023-09-02 08:21:09'),(56,NULL,'Sapiente error cum v','46','Voluptas dignissimos','2023-09-02 08:21:11','2023-09-02 08:21:11'),(57,NULL,'Fuga Aspernatur tem','36','Irure irure Nam enim','2023-09-02 08:27:41','2023-09-02 08:27:41'),(58,NULL,'Reprehenderit qui vo','77','Qui cum tenetur cons','2023-09-02 08:34:50','2023-09-02 08:34:50'),(59,NULL,'Voluptatem duis impe','98','Aute proident et pe','2023-09-02 08:45:44','2023-09-02 08:45:44'),(60,NULL,'Quaerat iure volupta','74','Qui eum rerum neque ','2023-09-02 08:47:38','2023-09-02 08:47:38'),(61,57,'Aliquip tempora plac','3','Ex ea quasi aute del','2023-09-02 08:50:17','2023-09-02 08:50:17'),(62,58,'Maiores elit cillum','74','Incidunt incidunt ','2023-09-02 08:56:33','2023-09-02 08:56:33');
/*!40000 ALTER TABLE `siblings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `classroom_id` bigint(20) unsigned NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lrn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0:active | 1:inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `students_classroom_id_foreign` (`classroom_id`),
  CONSTRAINT `students_classroom_id_foreign` FOREIGN KEY (`classroom_id`) REFERENCES `classrooms` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,2,'Akira','Kay','Hooper','43232423423',0,'2023-08-19 16:55:02','2023-08-19 17:08:59'),(3,1,'Reiss ','Kei','Mai','231312313',0,'2020-09-26 14:13:27',NULL),(6,1,'Joshua','C. ','Ledda','3213132131',0,'2021-08-12 14:13:20',NULL),(7,1,'Melodias','K','Zura','432424324',0,'2022-08-18 14:12:52',NULL),(8,1,'Sydnee','Thomas Morgan','Diaz','54',0,'2023-08-20 02:34:35','2023-08-20 02:34:35'),(9,1,'Sara','Vincent Day','Velasquez','24',0,'2023-08-20 02:34:38','2023-08-20 02:34:38'),(10,1,'Leila','Aileen Woodard','Roy','30',0,'2023-08-20 02:34:41','2023-08-20 02:34:41'),(11,1,'Jerome','Malcolm Ewing','Griffith','18',0,'2023-08-20 02:34:45','2023-08-20 02:34:45'),(12,1,'Wing','Paula Rodgers','Lawson','59',0,'2023-08-20 02:34:47','2023-08-20 02:34:47'),(13,1,'Xena','Carolyn Cooke','Tate','56',0,'2023-08-20 02:34:50','2023-08-20 02:34:50'),(14,1,'Quinn','Tiger Pacheco','Buckner','53',0,'2023-08-20 02:35:01','2023-08-20 02:35:01'),(15,1,'Priscilla','Madison Carney','Sparks','39',0,'2023-08-20 02:35:06','2023-08-20 02:35:06'),(16,1,'Eve','MacKenzie Pitts','Montgomery','32',0,'2023-08-20 22:30:59','2023-08-20 22:30:59'),(17,1,'Tamekah','Mira Page','Potts','98',0,'2023-08-20 22:31:07','2023-08-20 22:31:07'),(18,2,'Ledda ','Joshua','Reiss Mai','232323',1,'2023-08-20 22:31:14','2023-08-28 00:28:22'),(19,1,'Aki','Reiss','Sher','4324242',0,NULL,NULL);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int(11) NOT NULL DEFAULT 0 COMMENT '0:User|1:Admin|2:advise',
  `classroom_id` bigint(20) unsigned DEFAULT NULL COMMENT '0: w/o advisee',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_classroom_id_foreign` (`classroom_id`),
  CONSTRAINT `users_classroom_id_foreign` FOREIGN KEY (`classroom_id`) REFERENCES `classrooms` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin Akira','admin@gmail.com',NULL,'$2y$10$Tps4Q6AQVgHen5UglurkFudy4OjDo9x9al4oAnbFE0FGfdloScvzm',1,NULL,'0',NULL,'2023-08-19 16:52:00','2023-09-01 22:10:17'),(2,'Adviser Akira','adviser@gmail.com',NULL,'$2y$10$qki9cfjZwzE0ZSNtJGLj9.KH0yh0FQDzSIRb.i2d.eGy7NktKjCC6',2,1,'0',NULL,'2023-08-22 05:03:09','2023-08-26 18:56:21'),(3,'User','user@gmail.com',NULL,'$2y$10$Ky9Uf1Ch65N2sqAkkTxR6OeHWmhn10eIPWXXEmD3sCv7mh6oFi6aa',0,NULL,'0',NULL,'2023-08-29 11:50:57','2023-08-29 11:50:57'),(4,'Dana Herman','gusaxywulu@mailinator.com',NULL,'$2y$10$tcs7mmwDIAqY78WTAg1bGOd9tBtWnvKtknwBJwQkEVODC/t/KnaUi',0,NULL,'0',NULL,'2023-08-29 11:52:47','2023-08-29 11:52:47'),(5,'Yvonne Stout','vycugone@mailinator.com',NULL,'$2y$10$mndifwIGxGqo46xKo9VPM.F4AxZAZM.N8i0xTywAkRtAu/1aggkdu',0,NULL,'0',NULL,'2023-08-29 23:35:19','2023-08-29 23:35:19'),(6,'Excepteur iusto ut i','penig@mailinator.com',NULL,'Pa$$w0rd!',2,NULL,'0',NULL,'2023-08-30 03:24:49','2023-08-30 03:24:49'),(7,'Admin Aki','lyhuf@mailinator.com',NULL,'Pa$$w0rd!',1,NULL,'0',NULL,'2023-08-30 03:28:43','2023-08-30 03:28:43'),(8,'Teacher','akireiss@gmail.com',NULL,'Pa$$w0rd!',2,2,'0',NULL,'2023-08-30 03:29:23','2023-08-30 03:29:23'),(9,'Et iusto voluptatem','pafineh@mailinator.com',NULL,'Pa$$w0rd!',1,NULL,'0',NULL,'2023-08-30 03:32:39','2023-08-30 03:32:39'),(10,'Ad distinctio Ipsum','hovilifico@mailinator.com',NULL,'Pa$$w0rd!',2,1,'0',NULL,'2023-08-30 03:32:51','2023-08-30 03:32:51'),(11,'Libero aliquid quibu','hygufelo@mailinator.com',NULL,'Pa$$w0rd!',2,2,'0',NULL,'2023-08-30 03:33:02','2023-08-30 03:33:02'),(12,'Omnis do adipisci qu','hologifyl@mailinator.com',NULL,'Pa$$w0rd!',2,1,'0',NULL,'2023-08-30 03:33:13','2023-08-30 03:33:13'),(13,'adasd','dsadas@gmail.com',NULL,'sadasdaddasd',0,NULL,'0',NULL,'2023-08-30 13:50:36','2023-08-30 13:50:36'),(14,'Akira','reiss@gmail.com',NULL,'fsdfdsfsddsfsffsdfsdf',0,NULL,'0',NULL,'2023-08-30 13:57:36','2023-08-30 13:57:36'),(15,'Joshua Ledda','joshua.ledda@student.dmmmsu.edu.ph',NULL,'$2y$10$GPMkPbyPjgJkHBUmu2pzOuhlZXhNozSQNOPODqT7dZ5oP.qJ9hSIq',0,NULL,'0','yOlL77PQ2buY7H2QFyNV9cWcyBJWTYZB2vp9IPjIwiTHzJhGijMQAFNLnXV6','2023-08-30 19:12:43','2023-08-30 19:24:06'),(16,'Cooper Pena','hehiwel@mailinator.com',NULL,'$2y$10$HZyFRKxMLR.Rha4UsN8YsuD.LWo9RyuEwJadj5vFqME0U8evQAtcu',0,NULL,'0',NULL,'2023-09-02 07:51:26','2023-09-02 07:51:26');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `vitamins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vitamins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profile_id` bigint(20) unsigned NOT NULL,
  `vitamins` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `vitamins_profile_id_foreign` (`profile_id`),
  CONSTRAINT `vitamins_profile_id_foreign` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `vitamins` WRITE;
/*!40000 ALTER TABLE `vitamins` DISABLE KEYS */;
INSERT INTO `vitamins` VALUES (142,57,'Ut et sequi qui exer','2023-09-02 08:50:17','2023-09-02 08:50:17'),(143,57,'Sit nesciunt ut si','2023-09-02 08:50:17','2023-09-02 08:50:17'),(144,57,'Sunt libero aut quos','2023-09-02 08:50:17','2023-09-02 08:50:17'),(145,58,'Dolore Nam animi qu','2023-09-02 08:56:33','2023-09-02 08:56:33'),(146,58,'Officia ullam sunt q','2023-09-02 08:56:33','2023-09-02 08:56:33'),(147,58,'Facilis iusto sit au','2023-09-02 08:56:33','2023-09-02 08:56:33');
/*!40000 ALTER TABLE `vitamins` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

