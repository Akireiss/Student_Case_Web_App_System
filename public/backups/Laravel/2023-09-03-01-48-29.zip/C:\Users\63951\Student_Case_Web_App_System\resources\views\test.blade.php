@extends('layouts.dashboard.index')
@section('content')
<div>
    {{-- <livewire:test-table/> --}}
    <livewire:adviser.student-profile-table/>
</div>
@endsection
