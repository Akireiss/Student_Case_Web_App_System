@include('layouts.header')

<body>

    <main class="">
        @yield('content')
    </main>
    <x-footer />
    </div>



    @livewireScripts
</body>

</html>
