<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['selected' => null]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['selected' => null]); ?>
<?php foreach (array_filter((['selected' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<select <?php echo e($attributes->merge(['class' => 'border-gray-300 focus:border-indigo-500 py-2.5 bg-gray-50
    focus:ring-indigo-500 rounded-md shadow-sm w-full text-gray-800'])); ?>>
<option selected value="">Choose from below</option>
    <?php echo e($slot); ?>

</select>
<?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/components/select.blade.php ENDPATH**/ ?>