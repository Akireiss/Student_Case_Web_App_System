<div>
    <div x-data="{ showTable: true, showForm: false }">
        <div x-show="showTable">
            <div class="flex items-center justify-between my-6">
                <h6 class="text-lg font-semibold
                  text-gray-600 dark:text-gray-300 flex-shrink-0">
                    List Of Reports
                </h6>
                <div class="flex justify-end mt-4">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['xOn:click' => 'showTable = false; showForm = true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-on:click' => 'showTable = false; showForm = true']); ?>
                        Add
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>
            </div>
            <div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('anecdota-table', [])->html();
} elseif ($_instance->childHasBeenRendered('l2341005218-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2341005218-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2341005218-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2341005218-0');
} else {
    $response = \Livewire\Livewire::mount('anecdota-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2341005218-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>

        <div x-cloak x-show="showForm">

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('student.report', [])->html();
} elseif ($_instance->childHasBeenRendered('l2341005218-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l2341005218-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2341005218-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2341005218-1');
} else {
    $response = \Livewire\Livewire::mount('student.report', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2341005218-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        </div>
    </div>

</div>
<?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/livewire/admin/report.blade.php ENDPATH**/ ?>