<div>

    <div class="flex justify-between items-center">
        <h6 class="text-xl font-bold">
            Grade: <?php echo e(auth()->user()->classroom->grade_level); ?> <?php echo e(auth()->user()->classroom->section); ?> Profiles
        </h6>
        <div>
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link','data' => ['href' => url('adviser/student-profile/add')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(url('adviser/student-profile/add'))]); ?>
                Add
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

        </div>
    </div>

   <div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('adviser.student-profile-table', [])->html();
} elseif ($_instance->childHasBeenRendered('l2867560927-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2867560927-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2867560927-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2867560927-0');
} else {
    $response = \Livewire\Livewire::mount('adviser.student-profile-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2867560927-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
   </div>
</div>
<?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/livewire/adviser/student-profile.blade.php ENDPATH**/ ?>