@extends('layouts.dashboard.index')

@section('content')

<livewire:student.report/>

@endsection
