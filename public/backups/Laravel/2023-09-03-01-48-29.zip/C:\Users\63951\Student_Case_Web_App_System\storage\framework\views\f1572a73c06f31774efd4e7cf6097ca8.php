<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="flex items-center h-full p-16 text-black dark:text-gray-100">
	<div class="container flex flex-col items-center justify-center px-5 mx-auto my-8">
		<div class="max-w-md text-center">
			<h2 class="mb-8 font-extrabold text-9xl dark:text-gray-600">
				<span class="sr-only">Error</span>404
			</h2>
			<p class="text-2xl font-semibold md:text-3xl dark:text-gray-400">Sorry, we couldn't find this page.</p>
			<p class="mt-4 mb-8 dark:text-gray-400">But dont worry, you can find plenty of other things by clicking the button.</p>
			<a href="<?php echo e(url()->previous()); ?>" class="px-8 py-3 bg-green-600 shadow-md font-semibold rounded dark:bg-green-400 dark:text-gray-900">Return Back</a>
		</div>
	</div>
</section>

<?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/components/404.blade.php ENDPATH**/ ?>