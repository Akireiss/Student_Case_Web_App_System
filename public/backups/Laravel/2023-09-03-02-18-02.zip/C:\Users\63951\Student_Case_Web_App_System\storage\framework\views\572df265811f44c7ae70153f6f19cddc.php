<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'livewire-powergrid::components.editable','data' => ['tableName' => $tableName,'primaryKey' => $primaryKey,'row' => $row,'field' => $field,'theme' => $theme,'currentTable' => $currentTable,'showErrorBag' => $showErrorBag,'editable' => $editable]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('livewire-powergrid::editable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tableName' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tableName),'primaryKey' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($primaryKey),'row' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($row),'field' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($field),'theme' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($theme),'currentTable' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentTable),'showErrorBag' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($showErrorBag),'editable' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($editable)]); ?>
     <?php $__env->slot('input', null, []); ?> 
        <div
            x-ref="editable"
            x-text="content"
            value="<?php echo e(html_entity_decode($row->{$field}, ENT_QUOTES, 'utf-8')); ?>"
            placeholder="<?php echo e(html_entity_decode($row->{$field}, ENT_QUOTES, 'utf-8')); ?>"
            contenteditable
            class="pg-single-line <?php echo e($theme->editable->inputClass); ?>"
            <?php if(data_get($editable, 'saveOnMouseOut')): ?> x-on:mousedown.outside="save()" <?php endif; ?>
            x-on:keydown.enter="save()"
            :id="`editable-` + dataField + `-` + id"
            x-on:keydown.esc="cancel"
        >
        </div>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/vendor/livewire-powergrid/components/frameworks/tailwind/editable.blade.php ENDPATH**/ ?>