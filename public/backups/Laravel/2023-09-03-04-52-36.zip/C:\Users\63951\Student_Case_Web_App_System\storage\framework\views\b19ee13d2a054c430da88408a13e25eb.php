<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-between my-6">
    <h4 class="text-lg font-semibold text-gray-600 dark:text-gray-300 flex-shrink-0">
        Students Profile
    </h4>
    <div class="flex-grow flex justify-end">
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link','data' => ['href' => ''.e(url('admin/student-profile/add')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(url('admin/student-profile/add')).'']); ?>
            Add
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
</div>

<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('student-profile-table', [])->html();
} elseif ($_instance->childHasBeenRendered('z7oPNkw')) {
    $componentId = $_instance->getRenderedChildComponentId('z7oPNkw');
    $componentTag = $_instance->getRenderedChildComponentTagName('z7oPNkw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('z7oPNkw');
} else {
    $response = \Livewire\Livewire::mount('student-profile-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('z7oPNkw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>


















<?php echo $__env->make('layouts.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/admin/student-profile/index.blade.php ENDPATH**/ ?>