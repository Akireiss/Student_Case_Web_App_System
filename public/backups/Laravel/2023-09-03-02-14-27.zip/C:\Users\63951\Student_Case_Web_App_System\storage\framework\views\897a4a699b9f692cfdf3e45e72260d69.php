<div>

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('student.report', [])->html();
} elseif ($_instance->childHasBeenRendered('l795017071-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l795017071-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l795017071-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l795017071-0');
} else {
    $response = \Livewire\Livewire::mount('student.report', []);
    $html = $response->html();
    $_instance->logRenderedChild('l795017071-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

</div>
<?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/livewire/adviser/report.blade.php ENDPATH**/ ?>