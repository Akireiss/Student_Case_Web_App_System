<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['columns' => '1', 'gap' => '6', 'px' => '4', 'mt' => '0']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['columns' => '1', 'gap' => '6', 'px' => '4', 'mt' => '0']); ?>
<?php foreach (array_filter((['columns' => '1', 'gap' => '6', 'px' => '4', 'mt' => '0']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="grid  grid-cols-1 sm:grid-cols-2 md:grid-cols-3
 lg:grid-cols-<?php echo e($columns); ?> gap-<?php echo e($gap); ?> px-<?php echo e($px); ?> mt-<?php echo e($mt); ?>">
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/components/grid.blade.php ENDPATH**/ ?>