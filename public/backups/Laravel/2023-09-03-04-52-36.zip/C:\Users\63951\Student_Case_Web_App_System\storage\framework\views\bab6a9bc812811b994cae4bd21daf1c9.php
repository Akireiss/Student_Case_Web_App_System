<?php $__env->startSection('content'); ?>
<div>
    <h6 class="text-xl font-bold text-left ">
       Report History
    </h6>
    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('adviser.report-history-table', [])->html();
} elseif ($_instance->childHasBeenRendered('sfOyhO2')) {
    $componentId = $_instance->getRenderedChildComponentId('sfOyhO2');
    $componentTag = $_instance->getRenderedChildComponentTagName('sfOyhO2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sfOyhO2');
} else {
    $response = \Livewire\Livewire::mount('adviser.report-history-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('sfOyhO2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/staff/report-history/index.blade.php ENDPATH**/ ?>