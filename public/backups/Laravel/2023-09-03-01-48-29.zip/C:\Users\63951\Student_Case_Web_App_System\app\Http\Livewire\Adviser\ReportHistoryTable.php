<?php

namespace App\Http\Livewire\Adviser;

use App\Models\Report;
use App\Models\Anecdotal;
use Illuminate\Support\Carbon;
use Illuminate\Database\Eloquent\Builder;
use PowerComponents\LivewirePowerGrid\Filters\Filter;
use PowerComponents\LivewirePowerGrid\Rules\{Rule, RuleActions};
use PowerComponents\LivewirePowerGrid\Traits\{ActionButton, WithExport};
use PowerComponents\LivewirePowerGrid\{Button, Column, Exportable, Footer, Header, PowerGrid, PowerGridComponent, PowerGridColumns};

final class ReportHistoryTable extends PowerGridComponent
{
    use ActionButton;
    use WithExport;

    /*
    |--------------------------------------------------------------------------
    |  Features Setup
    |--------------------------------------------------------------------------
    */
    public function setUp(): array
    {
        return [
            Header::make(),
            Footer::make()
                ->showPerPage()
                ->showRecordCount(),
        ];
    }

    /**
     * PowerGrid datasource.
     *
     * @return Builder<\App\Models\Report>
     */public function datasource(): Builder
    {
        $userId = auth()->user()->id;
        return Report::query()
            ->join('anecdotal', 'reports.anecdotal_id', '=', 'anecdotal.id')
            ->join('students', 'anecdotal.student_id', '=', 'students.id')
            ->where('reports.user_id', $userId)
            ->with('users')
            ->with('anecdotal')
            ->select(
            'reports.*',
            'reports.created_at',
            'students.first_name', 'students.last_name');
    }



    public function relationSearch(): array
    {
        return [
        ];
    }

    public function addColumns(): PowerGridColumns
    {
        return PowerGrid::columns()
            ->addColumn('users.name')
            ->addColumn('students.first_name', function (Report $model) {
                return $model->anecdotal->student->first_name . ' ' . $model->anecdotal->student->last_name;
            })
            ->addColumn('anecdotal.case_status', function (Report $model) {
                return $model->anecdotal->getStatusTextAttribute();
            })

            ->addColumn('reports.created_at')
            ->addColumn('created_at_formatted', fn(Report $model) => Carbon::parse($model->created_at)->format('F j, Y'));
    }

    public function columns(): array
    {
        return [
            Column::make('Reporter Name', 'users.name'),
            Column::make('Student Name', 'students.first_name')->sortable(),
            Column::make('Status', 'anecdotal.case_status'),
            Column::make('Created at', 'created_at_formatted', 'reports.created_at')->sortable(),
        ];
    }

    public function filters(): array
    {
        return [
            Filter::datetimepicker('created_at_formatted', 'reports.created_at'),
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | Actions Method
    |--------------------------------------------------------------------------
    */

    public function actions(): array
    {
    $buttons = [];

    if (auth()->user()->role === 0) {
        $buttons[] = Button::make('view', 'View')
            ->class('bg-indigo-500 cursor-pointer text-white px-3 py-2.5 m-1 rounded text-sm')
            ->route('user.report.view', function (\App\Models\Report $model) {
                return ['report' => $model->id];
            });

        $buttons[] = Button::make('edit', 'Edit')
            ->class('bg-indigo-500 cursor-pointer text-white px-3 py-2.5 m-1 rounded text-sm')
            ->route('user.report.edit', function (\App\Models\Report $model) {
                return ['report' => $model->id];
            });
    } elseif (auth()->user()->role === 2) {
        $buttons[] = Button::make('view', 'View')
            ->class('bg-indigo-500 cursor-pointer text-white px-3 py-2.5 m-1 rounded text-sm')
            ->route('report.view', function (\App\Models\Report $model) {
                return ['report' => $model->id];
            });

        $buttons[] = Button::make('edit', 'Edit')
            ->class('bg-indigo-500 cursor-pointer text-white px-3 py-2.5 m-1 rounded text-sm')
            ->route('report.edit', function (\App\Models\Report $model) {
                return ['report' => $model->id];
            });
    }

    return $buttons;
    }

    public function actionRules(): array
    {
        return [
            Rule::button('edit')
                ->when(fn($report) => $report->anecdotal->case_status === 1)
                ->hide(),
        ];
    }

}
