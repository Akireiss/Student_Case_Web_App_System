<?php $__env->startSection('content'); ?>
    <div>

        <h2 class="m-1 text-2xl font-semibold text-gray-700 dark:text-gray-200">
            Dashboard
        </h2>



        <div x-data="{ showAllYear: true }" class="flex justify-end my-2">
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['id' => 'toggle-time-range','@click' => 'showAllYear = !showAllYear','xText' => 'showAllYear ? \'All year\' : \'Current year\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'toggle-time-range','@click' => 'showAllYear = !showAllYear','x-text' => 'showAllYear ? \'All year\' : \'Current year\'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </div>

        <div class="grid gap-6 mb-3 md:grid-cols-2 xl:grid-cols-4">
            <!-- Card -->

                <a href="<?php echo e(url('admin/settings/students')); ?>" class="flex items-center p-4 bg-white rounded-lg shadow-md  dark:bg-gray-800">
                    <div class="p-3 mr-4 text-orange-500 bg-orange-100 rounded-full dark:text-orange-100 dark:bg-orange-500">
                    <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z">
                        </path>
                    </svg>
                </div>
                <div>
                    <p class="mb-2 text-sm font-medium text-gray-600 dark:text-gray-400">
                        Total students
                    </p>
                    <p class="text-lg font-semibold text-gray-700 dark:text-gray-200" id="total-students">

                    </p>
                </div>
            </a>




            <!-- Card -->
            <a href="<?php echo e(url('admin/reports')); ?>"  class="flex items-center p-4 bg-white rounded-lg shadow-md  dark:bg-gray-800">
                <div class="p-3 mr-4 text-green-500 bg-green-100 rounded-full dark:text-green-100 dark:bg-green-500">

                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                        stroke="currentColor" class="w-5 h-5">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25
                    0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664
                     0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0
                      1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621
                       0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z" />
                    </svg>



                </div>
                <div>
                    <p class="mb-2 text-sm font-medium text-gray-600 dark:text-gray-400">
                        Total Cases
                    </p>
                    <p class="text-lg font-semibold text-gray-700 dark:text-gray-200" id="total-cases">
                    </p>
                </div>
            </a>
            <!-- Card -->
            <div class="flex items-center p-4 bg-white rounded-lg shadow-md
            dark:bg-gray-800">
                <div class="p-3 mr-4 text-blue-500 bg-blue-100 rounded-full dark:text-blue-100 dark:bg-blue-500">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor" class="w-5 h-5">
                           <path stroke-linecap="round" stroke-linejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />
                      </svg>

                </div>
                <div>
                    <p class="mb-2 text-sm font-medium text-gray-600 dark:text-gray-400">
                        Pending Cases
                    </p>
                    <p id="pending-cases" class="text-lg font-semibold text-gray-700 dark:text-gray-200">

                    </p>
                </div>
            </div>
            <!-- Card -->
            <div class="flex items-center p-4 bg-white
             rounded-lg shadow-md  dark:bg-gray-800">
                <div class="p-3 mr-4 text-teal-500 bg-teal-100 rounded-full dark:text-teal-100 dark:bg-teal-500">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                        stroke="currentColor" class="w-5 h-5">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M11.35 3.836c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m8.9-4.414c.376.023.75.05 1.124.08 1.131.094 1.976 1.057 1.976 2.192V16.5A2.25 2.25 0 0118 18.75h-2.25m-7.5-10.5H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V18.75m-7.5-10.5h6.375c.621 0 1.125.504 1.125 1.125v9.375m-8.25-3l1.5 1.5 3-3.75" />
                    </svg>

                </div>
                <div>
                    <p class="mb-2 text-sm font-medium text-gray-600 dark:text-gray-400">
                        Resolved Cases
                    </p>
                    <p id="resolved-cases" class="text-lg font-semibold text-gray-700 dark:text-gray-200">

                    </p>
                </div>
            </div>

        </div>


        <div class="grid gap-6 mb-3 md:grid-cols-2 xl:grid-cols-4">

            <div class="py-1">
                <div class="bg-red-500 border-l-4 text-white rounded-md border-red-600 p-2.5 mb-1 shadow-md"
                     role="alert" id="weekly-alert">
                    <p class="font-bold">Notice</p>
                    <p>The cases that have resolved on last (date) from (studentname)
                       don't you want to check the student?
                    <span id="resolved-cases-count"></span></p>
                </div>
            </div>




            <div class="py-1">
           <div class="bg-red-500 border-l-4 text-white  rounded-md border-red-600 p-2.5 mb-1
           shadow-md hidden-alert-weekly"
            role="alert" id="weekly-alert">
               <p class="font-bold">Notice</p>
               <p>Total Reports This Week: <span id="weekly-report-count"></span></p>
           </div>
       </div>



        <div class="py-1">
            <div class="bg-red-500 border-l-4  rounded-md   border-red-600  p-2.5 mb-1
            shadow-md
             text-white" role="alert" id="monthly-alert">
                <p class="font-bold">Notice</p>
                <p>Total Reports This Month: <span id="monthly-report-count"></span></p>
            </div>
        </div>



               </div>




        <div class="grid gap-6 mb-8 md:grid-cols-2 xl:grid-cols-2">

            <div class="min-w-0 p-4 shadow-md bg-white rounded-lg ring-1 ring-black ring-opacity-5 dark:bg-gray-800">
                <div class="flex justify-between items-start">

                    <h4 class="mb-4 font-semibold text-gray-800 dark:text-gray-300">
                        Cases Status For the School Year
                    </h4>

                    <div x-data="{ open: false }" class="inline-block">
                        <!-- Dropdown button -->
                        <div class="relative inline-block text-left">
                            <button @click="open = !open">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 6.75a.75.75 0 110-1.5.75.75 0 010 1.5zM12 12.75a.75.75 0 110-1.5.75.75 0 010 1.5zM12 18.75a.75.75 0 110-1.5.75.75 0 010 1.5z" />
                                </svg>
                            </button>
                            <!-- Dropdown menu -->
                            <div x-show="open" @click.away="open = false" @click.away="open = false" class="origin-top-right absolute
                            top-7 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 divide-y divide-gray-100">
                                <!-- Dropdown items -->
                                <div class="py-1" role="menu" aria-orientation="vertical" aria-labelledby="options-menu">
                                    <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">Option 1</a>
                                    <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">Option 2</a>
                                    <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100" role="menuitem">Option 3</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <canvas id="bars"></canvas>
                <div class="flex justify-center mt-4 space-x-3 text-sm text-gray-600 dark:text-gray-400">
                    <!-- Chart legend -->
                    <div class="flex items-center">
                        <span class="inline-block w-3 h-3 mr-1 bg-red-500 rounded-full"></span>
                        <span>Pending</span>
                    </div>
                    <div class="flex items-center">
                        <span class="inline-block w-3 h-3 mr-1 bg-teal-500 rounded-full bg-primary-600"></span>
                        <span>Ongoing</span>
                    </div>
                    <div class="flex items-center">
                        <span class="inline-block w-3 h-3 mr-1 bg-green-500 rounded-full bg-primary-600"></span>
                        <span>Resolved</span>
                    </div>
                </div>
            </div>




            <div class="min-w-0 p-4 shadow-md bg-white rounded-lg ring-1 ring-black ring-opacity-5 dark:bg-gray-800">
                <h4 class="mb-4 font-semibold text-gray-800 dark:text-gray-300">
                    Offenses Usage
                </h4>
                <canvas id="pie"></canvas>
                <div class="flex justify-center mt-4 space-x-3 text-sm text-gray-600 dark:text-gray-400">
                    <!-- Chart legend -->
                    <div class="flex items-center">
                        <span class="inline-block w-3 h-3 mr-1 rounded-full"></span>
                        <span>Offenses</span>
                    </div>

                </div>
            </div>




        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/admin/dashboard/dashboard.blade.php ENDPATH**/ ?>