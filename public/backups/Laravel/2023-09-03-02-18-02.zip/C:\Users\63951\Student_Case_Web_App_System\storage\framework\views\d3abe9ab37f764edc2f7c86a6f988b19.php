<div id="messageContainer">
    <?php if(session()->has('message')): ?>
        <span class="text-green-500 mx-4">
            <?php echo e(session('message')); ?>

        </span>
    <?php endif; ?>
</div>

<?php $__env->startPush('scripts'); ?>

<script>
    setTimeout(function() {
        var messageContainer = document.getElementById('messageContainer');
        if (messageContainer) {
            messageContainer.remove();
        }
    }, 3000);
</script>
    <?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/components/text-alert.blade.php ENDPATH**/ ?>