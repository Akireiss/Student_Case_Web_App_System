<?php echo e($slot); ?>

<?php /**PATH C:\Users\63951\Student_Case_Web_App_System\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>