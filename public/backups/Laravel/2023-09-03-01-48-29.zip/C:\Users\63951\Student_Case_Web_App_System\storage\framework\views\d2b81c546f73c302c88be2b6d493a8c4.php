<?php $__env->startSection('content'); ?>
    <div class="mx-auto">
        <div class="flex justify-between items-center">
            <h6 class="text-xl font-bold text-left ">
                Report Student
            </h6>

        </div>
        <div>

          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.user.users-table', [])->html();
} elseif ($_instance->childHasBeenRendered('ChOTL5R')) {
    $componentId = $_instance->getRenderedChildComponentId('ChOTL5R');
    $componentTag = $_instance->getRenderedChildComponentTagName('ChOTL5R');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ChOTL5R');
} else {
    $response = \Livewire\Livewire::mount('admin.user.users-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('ChOTL5R', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/admin/user/index.blade.php ENDPATH**/ ?>