<div>
    <div class="container px-6 py-4 mx-auto">
        <div class="text-xl font-semibold text-gray-700">
            <a class="text-2xl font-bold transition-colors duration-300 transform text-green-400 lg:text-3xl dark:hover:text-green-500"
                href="<?php echo e(url('/')); ?>">CZCMNHS</a>
        </div>
    </div>

    <div class="pt-14 md:pt-24 p-0 md:p-5 container mx-auto text-center md:space-x-1">
        <div class="container px-3 mx-auto flex flex-wrap flex-col md:flex-row items-center justify-center">
            <!-- Left Col -->
            <div class="flex flex-col w-full md:w-2/5 justify-center text-center md:text-center mx-auto">
                <p class="uppercase tracking-loose w-full md:text-center sm:text-lg">CASTOR Z. CONCEPCION MEMORIAL NATIONAL HIGH SCHOOL</p>
                <div class="hidden md:block text-sm text-center">
                    <h1 class="my-1 text-sm md:text-5xl font-bold leading-tight text-black">
                        A Happy School, Sustaining Excellence.
                    </h1>
                </div>
                <h1 class="my-1 text-sm md:text-5xl font-bold leading-tight text-black md:hidden">
                    A Happy School, Sustaining Excellence.
                </h1>
            </div>

            <div class="w-full md:w-3/5 py-3 text-center ">
                <img class="w-full md:w-1/2 z-50 mx-auto px-8 " src="<?php echo e(url('assets/image/form.svg')); ?>" />
            </div>
        </div>

        <div class="w-full lg:px-72  ">
            <div class="px-4" x-data="{ isOpen: <?php if ((object) ('isOpen') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('isOpen'->value()); ?>')<?php echo e('isOpen'->hasModifier('defer') ? '.defer' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('isOpen'); ?>')<?php endif; ?>, studentName: <?php if ((object) ('studentName') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('studentName'->value()); ?>')<?php echo e('studentName'->hasModifier('defer') ? '.defer' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('studentName'); ?>')<?php endif; ?> }">
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['for' => 'studentName']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'studentName']); ?>
                    Student Name
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                <div class="relative">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['wire:model.debounce.300ms' => 'studentName','@focus' => 'isOpen = true','@click.away' => 'isOpen = false','@keydown.escape' => 'isOpen = false','@keydown' => 'isOpen = true','type' => 'text','id' => 'studentName','name' => 'studentName','placeholder' => 'Start typing to search.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.debounce.300ms' => 'studentName','@focus' => 'isOpen = true','@click.away' => 'isOpen = false','@keydown.escape' => 'isOpen = false','@keydown' => 'isOpen = true','type' => 'text','id' => 'studentName','name' => 'studentName','placeholder' => 'Start typing to search.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.error','data' => ['fieldName' => 'studentName']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['fieldName' => 'studentName']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.error','data' => ['fieldName' => 'studentId']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['fieldName' => 'studentId']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                    <span x-show="studentName !== ''" @click="studentName = ''; isOpen = false"
                        class="absolute right-3 top-2 cursor-pointer text-red-600 font-bold">
                        &times;
                    </span>
                    <?php if($studentName && count($students) > 0): ?>
                        <ul class="bg-white border border-gray-300 mt-2 rounded-md w-full max-h-48 overflow-auto absolute z-10"
                            x-show="isOpen">
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="px-4 py-2 cursor-pointer hover:bg-gray-200"
                                    wire:click="selectStudent('<?php echo e($student->id); ?>',
                                     '<?php echo e($student->first_name); ?> <?php echo e($student->middle_name); ?> <?php echo e($student->last_name); ?>')"
                                    x-on:click="isOpen = false">
                                    <?php echo e($student->first_name); ?> <?php echo e($student->middle_name); ?>

                                    <?php echo e($student->last_name); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php elseif($studentName): ?>
                            <span class="text-red-500 text-sm">
                                No Student Found
                            </span>
                        </ul>
                    <?php endif; ?>
                </div>
                <input type="hidden" name="studentId" wire:model="studentId">
            </div>
        </div>


    </div>


    <?php if($showCreateLink): ?>
    <div class="max-w-lg mx-auto text-center my-3">
        <p class="text-black text-center">
            Don't have a profile? <a target="_blank" href="<?php echo e(url('student/profile/create')); ?>" class="font-bold hover:underline">Create Here</a>.
        </p>
    </div>
    <?php endif; ?>

</div>
<?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/livewire/student/student-form.blade.php ENDPATH**/ ?>