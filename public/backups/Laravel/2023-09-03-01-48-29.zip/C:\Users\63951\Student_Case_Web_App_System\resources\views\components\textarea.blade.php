<div>
    <textarea {{ $attributes->merge(['class' => 'w-full rounded-md shadow-sm
    border-black focus:ring focus:ring-indigo-200 text-gray-800']) }} >
    {{ $slot }}</textarea>
</div>
