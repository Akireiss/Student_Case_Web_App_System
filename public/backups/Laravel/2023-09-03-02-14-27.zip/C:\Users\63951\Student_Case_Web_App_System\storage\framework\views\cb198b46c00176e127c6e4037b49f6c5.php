<?php $__env->startSection('content'); ?>


<div class="flex items-center justify-between my-6">
    <h4 class="text-lg font-semibold text-gray-600 dark:text-gray-300 flex-shrink-0">
Audit Trail
    </h4>
    <div class="flex-grow flex justify-end">

    </div>
  </div>
<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('activity-table', [])->html();
} elseif ($_instance->childHasBeenRendered('hpgzd7E')) {
    $componentId = $_instance->getRenderedChildComponentId('hpgzd7E');
    $componentTag = $_instance->getRenderedChildComponentTagName('hpgzd7E');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hpgzd7E');
} else {
    $response = \Livewire\Livewire::mount('activity-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('hpgzd7E', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/admin/settings/audit-trail/index.blade.php ENDPATH**/ ?>