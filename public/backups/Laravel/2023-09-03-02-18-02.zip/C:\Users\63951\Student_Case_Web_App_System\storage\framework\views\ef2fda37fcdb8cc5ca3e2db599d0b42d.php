
<?php if(session('message')): ?>
<div class="bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4" role="alert">
    <p class="font-bold">Be Warned</p>
    <p><?php echo e(session('message')); ?></p>
  </div>
  <?php endif; ?>
<?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/components/alert.blade.php ENDPATH**/ ?>