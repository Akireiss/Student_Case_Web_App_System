<?php $__env->startSection('content'); ?>
<h6 class="text-xl font-bold text-left ">
    Grade:  <?php echo e(auth()->user()->classroom->grade_level); ?>  <?php echo e(auth()->user()->classroom->section); ?> Students
 </h6>
 <div>
     <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('adviser.student-table', [])->html();
} elseif ($_instance->childHasBeenRendered('L6SNDHH')) {
    $componentId = $_instance->getRenderedChildComponentId('L6SNDHH');
    $componentTag = $_instance->getRenderedChildComponentTagName('L6SNDHH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('L6SNDHH');
} else {
    $response = \Livewire\Livewire::mount('adviser.student-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('L6SNDHH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
 </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/staff/students/index.blade.php ENDPATH**/ ?>