<?php

namespace App\Models;

use App\Models\User;
use App\Models\Offenses;
use App\Models\Students;
use App\Models\ActionsTaken;
use Spatie\Activitylog\LogOptions;
use App\Http\Livewire\Admin\Student;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Anecdotal extends Model
{
    use HasFactory;
    use LogsActivity;

    protected $table = 'anecdotal';

    protected $fillable = [
        'student_id',
        'offense_id',
        'gravity',
        'short_description',
        'observation',
        'desired',
        'outcome',
        'letter',
        'case_status',
        'status'
    ];




    public function actionsTaken()
    {
        return $this->hasMany(ActionsTaken::class, 'anecdotal_id');
    }
    public function actions()
    {
        return $this->hasOne(AnecdotalOutcome::class, 'anecdotal_id');
    }

    public function offenses()
    {
        return $this->belongsTo(Offenses::class, 'offense_id');
    }

    public function report()
    {
        return $this->hasMany(Report::class, 'anecdotal_id');
    }

    public function students()
    {
        return $this->belongsTo(Students::class, 'student_id');
    }
    // TODO: for anecdotal table (still need some adjustment)
    public function student()
    {
        return $this->belongsTo(Students::class, 'student_id');
    }



    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['student_id', 'short_description', 'outcome']);
    }

    // !Table
    public static function codes()
    {
        return collect([
            ['case_status' => 0, 'label' => 'Pending'],
            ['case_status' => 1, 'label' => 'Ongoing'],
            ['case_status' => 2, 'label' => 'Resolved'],
        ]);
    }

        public static function gravityCodes()
    {
        return collect([
            ['gravity' => 0, 'label' => 'Low Severity'],
            ['gravity' => 1, 'label' => 'Moderate Severity'],
            ['gravity' => 2, 'label' => 'Medium Severity'],
            ['gravity' => 3, 'label' => 'High Severity'],
            ['gravity' => 4, 'label' => 'Critical Severity'],
        ]);
    }



    public function getStatusTextAttribute()
    {
        $value = $this->attributes['case_status']; // Retrieve the attribute value from the model

        switch ($value) {
            case 0:
                return 'Pending';
            case 1:
                return 'Ongoing';
            case 2:
                return 'Resolved';
            default:
                return 'Unknown';
        }
    }

    public function getGravityTextAttribute()
    {
        $value = $this->attributes['gravity'];

        switch ($value) {
            case 0:
                return 'Low Severity';
            case 1:
                return 'Moderate Severity';
            case 2:
                return 'Medium Severity';
            case 3:
                return 'High Severity';
            case 4:
                return 'Critical Severity';
            default:
                return 'Unknown';
        }
    }



}
