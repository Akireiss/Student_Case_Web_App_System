<div>

                <livewire:student.report />

</div>
