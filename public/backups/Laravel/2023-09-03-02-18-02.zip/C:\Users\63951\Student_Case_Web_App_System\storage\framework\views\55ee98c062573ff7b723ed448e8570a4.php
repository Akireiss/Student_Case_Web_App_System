<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>CZCMNHS</title>
    <link rel="icon" href="<?php echo e(asset('assets/image/logo.png')); ?>" type="image/x-icon">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>


    <link rel="stylesheet" href="<?php echo e(asset('assets/css/tailwind.output.css')); ?>" />
    <script src="<?php echo e(asset('assets/js/validation.js')); ?>"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js" defer></script>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
<?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/layouts/header.blade.php ENDPATH**/ ?>