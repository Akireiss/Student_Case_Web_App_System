// foreach ($this->profile->siblings as $index => $siblingModel) {
        //     if (isset($this->siblings[$index])) {
        //         $siblingModel->update([
        //             'sibling_name' => $this->siblings[$index]['name'],
        //             'sibling_age' => $this->siblings[$index]['age'],
        //             'sibling_grade_section' => $this->siblings[$index]['gradeSection'],
        //         ]);
        //     }
        // }

        // foreach ($this->profile->awards as $index => $rewardModel) {
        //     if (isset($this->rewards[$index])) {
        //         $rewardModel->update([
        //             'award_name' => $this->rewards[$index]['name'],
        //             'award_year' => $this->rewards[$index]['year'],
        //         ]);
        //     }
        // }
