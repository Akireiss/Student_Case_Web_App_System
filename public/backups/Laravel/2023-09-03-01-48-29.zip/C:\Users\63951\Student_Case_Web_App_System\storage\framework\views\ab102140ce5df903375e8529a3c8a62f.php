<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('student.report', [])->html();
} elseif ($_instance->childHasBeenRendered('2xPL8hi')) {
    $componentId = $_instance->getRenderedChildComponentId('2xPL8hi');
    $componentTag = $_instance->getRenderedChildComponentTagName('2xPL8hi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2xPL8hi');
} else {
    $response = \Livewire\Livewire::mount('student.report', []);
    $html = $response->html();
    $_instance->logRenderedChild('2xPL8hi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\63951\Student_Case_Web_App_System\resources\views/home.blade.php ENDPATH**/ ?>